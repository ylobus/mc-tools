import bpy
import bmesh
from bpy.props import BoolProperty
from bpy.app.handlers import persistent
from mathutils import Vector

# ---------------------------------------------------------------------------
# Persistent snapshot state (module-level, lives for the session)
# ---------------------------------------------------------------------------

# Object mode: { obj.name: Vector(world location) }
_obj_snapshot = {}

# Edit mode: { obj.name: [ Vector(co) per vert index ] }
_edit_snapshot = {}

# Whether we're currently applying a correction (prevents re-entry)
_correcting = False


def _is_active(scene):
    """Returns True if axis lock is enabled and at least one axis is locked."""
    props = scene.get("axis_lock_props")
    if props is None:
        return False
    p = scene.axis_lock_props
    return p.enabled and (p.lock_x or p.lock_y or p.lock_z)


def _get_free_axes(scene):
    """Returns a tuple (free_x, free_y, free_z) — True means movement IS allowed."""
    p = scene.axis_lock_props
    return (p.lock_x, p.lock_y, p.lock_z)


# ---------------------------------------------------------------------------
# Snapshot helpers
# ---------------------------------------------------------------------------

def _snapshot_object_mode(context):
    global _obj_snapshot
    _obj_snapshot = {}
    for obj in context.selected_objects:
        _obj_snapshot[obj.name] = obj.location.copy()


def _snapshot_edit_mode(context):
    global _edit_snapshot
    _edit_snapshot = {}
    for obj in context.objects_in_mode_unique_data:
        if obj.type != 'MESH':
            continue
        bm = bmesh.from_edit_mesh(obj.data)
        _edit_snapshot[obj.name] = {
            v.index: v.co.copy()
            for v in bm.verts
            if v.select
        }


def _take_snapshot(context):
    if context.mode == 'EDIT_MESH':
        _snapshot_edit_mode(context)
    elif context.mode == 'OBJECT':
        _snapshot_object_mode(context)


# ---------------------------------------------------------------------------
# Correction helpers
# ---------------------------------------------------------------------------

def _correct_object_mode(scene, context):
    global _obj_snapshot, _correcting
    if not _obj_snapshot:
        return

    lock_x, lock_y, lock_z = _get_free_axes(scene)
    changed = False

    for obj in context.selected_objects:
        if obj.name not in _obj_snapshot:
            continue
        old = _obj_snapshot[obj.name]
        new = obj.location

        corrected = Vector((
            new.x if lock_x else old.x,
            new.y if lock_y else old.y,
            new.z if lock_z else old.z,
        ))

        if (corrected - new).length > 1e-6:
            obj.location = corrected
            changed = True

    if changed:
        _correcting = True
        try:
            bpy.ops.ed.undo_push(message="Axis Lock Move")
        except Exception:
            pass
        _correcting = False


def _correct_edit_mode(scene, context):
    global _edit_snapshot, _correcting
    if not _edit_snapshot:
        return

    lock_x, lock_y, lock_z = _get_free_axes(scene)
    changed = False

    for obj in context.objects_in_mode_unique_data:
        if obj.type != 'MESH':
            continue
        if obj.name not in _edit_snapshot:
            continue

        bm = bmesh.from_edit_mesh(obj.data)
        snap = _edit_snapshot[obj.name]

        for v in bm.verts:
            if not v.select:
                continue
            if v.index not in snap:
                continue
            old = snap[v.index]
            new = v.co

            corrected = Vector((
                new.x if lock_x else old.x,
                new.y if lock_y else old.y,
                new.z if lock_z else old.z,
            ))

            if (corrected - new).length > 1e-6:
                v.co = corrected
                changed = True

        if changed:
            bmesh.update_edit_mesh(obj.data, loop_triangles=False)

    if changed:
        _correcting = True
        try:
            bpy.ops.ed.undo_push(message="Axis Lock Move")
        except Exception:
            pass
        _correcting = False


# ---------------------------------------------------------------------------
# Depsgraph handlers
# ---------------------------------------------------------------------------

@persistent
def _pre_handler(scene, depsgraph=None):
    """Snapshot positions before any update."""
    global _correcting
    if _correcting:
        return
    if not _is_active(scene):
        return

    context = bpy.context
    if context is None:
        return

    _take_snapshot(context)


@persistent
def _post_handler(scene, depsgraph=None):
    """After update: compare to snapshot and zero out disallowed axes."""
    global _correcting
    if _correcting:
        return
    if not _is_active(scene):
        return

    context = bpy.context
    if context is None:
        return

    if context.mode == 'OBJECT':
        _correct_object_mode(scene, context)
    elif context.mode == 'EDIT_MESH':
        _correct_edit_mode(scene, context)

    # Refresh snapshot for next operation
    _take_snapshot(context)


# ---------------------------------------------------------------------------
# Scene property group
# ---------------------------------------------------------------------------

class AxisLockProperties(bpy.types.PropertyGroup):
    enabled: BoolProperty(name="Axis Lock Active", default=False)
    lock_x: BoolProperty(name="X", default=True)
    lock_y: BoolProperty(name="Y", default=False)
    lock_z: BoolProperty(name="Z", default=False)


# ---------------------------------------------------------------------------
# Operators
# ---------------------------------------------------------------------------

class AXISLOCK_OT_toggle(bpy.types.Operator):
    """Toggle axis lock on/off"""
    bl_idname = "axislock.toggle"
    bl_label = "Toggle Axis Lock"
    bl_options = {'REGISTER'}

    def execute(self, context):
        props = context.scene.axis_lock_props
        props.enabled = not props.enabled
        # Take a fresh snapshot when enabling
        if props.enabled:
            _take_snapshot(context)
        return {'FINISHED'}


class AXISLOCK_OT_configure_and_enable(bpy.types.Operator):
    """Configure axes then activate lock  [Ctrl+Shift+Tab]"""
    bl_idname = "axislock.configure_and_enable"
    bl_label = "Axis Lock"
    bl_options = {'REGISTER'}

    lock_x: BoolProperty(name="X", default=True)
    lock_y: BoolProperty(name="Y", default=False)
    lock_z: BoolProperty(name="Z", default=False)

    def invoke(self, context, event):
        props = context.scene.axis_lock_props
        self.lock_x = props.lock_x
        self.lock_y = props.lock_y
        self.lock_z = props.lock_z
        return context.window_manager.invoke_popup(self, width=120)

    def draw(self, context):
        layout = self.layout
        layout.label(text="Lock Axes:")
        col = layout.column(align=True)
        col.prop(self, "lock_x", toggle=True)
        col.prop(self, "lock_y", toggle=True)
        col.prop(self, "lock_z", toggle=True)

    def execute(self, context):
        props = context.scene.axis_lock_props
        props.lock_x = self.lock_x
        props.lock_y = self.lock_y
        props.lock_z = self.lock_z
        props.enabled = True
        _take_snapshot(context)
        return {'FINISHED'}


# ---------------------------------------------------------------------------
# Header button + popover
# ---------------------------------------------------------------------------

class AXISLOCK_PT_popover(bpy.types.Panel):
    bl_label = "Axis Lock"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'HEADER'

    def draw(self, context):
        layout = self.layout
        props = context.scene.axis_lock_props

        layout.label(text="Lock Axes:")
        col = layout.column(align=True)
        col.prop(props, "lock_x", toggle=True)
        col.prop(props, "lock_y", toggle=True)
        col.prop(props, "lock_z", toggle=True)

        layout.separator()
        layout.prop(props, "enabled", text="Active", toggle=True, icon='LOCKED')


def draw_header_button(self, context):
    if context.area.type != 'VIEW_3D':
        return

    props = context.scene.axis_lock_props
    layout = self.layout

    axes = ""
    if props.lock_x: axes += "X"
    if props.lock_y: axes += "Y"
    if props.lock_z: axes += "Z"
    if not axes:
        axes = "—"

    row = layout.row(align=True)
    sub = row.row(align=True)
    sub.alert = props.enabled
    sub.operator(
        "axislock.toggle",
        text=axes,
        icon='LOCKED' if props.enabled else 'UNLOCKED',
        depress=props.enabled,
    )
    row.popover(
        panel="AXISLOCK_PT_popover",
        text="",
        icon='DOWNARROW_HLT',
    )


# ---------------------------------------------------------------------------
# Keymaps
# ---------------------------------------------------------------------------

addon_keymaps = []


def register_keymaps():
    wm = bpy.context.window_manager
    kc = wm.keyconfigs.addon
    if not kc:
        return

    for km_name in ('3D View', '3D View Generic'):
        km = kc.keymaps.new(name=km_name, space_type='VIEW_3D')
        kmi = km.keymap_items.new(
            "axislock.configure_and_enable",
            type='TAB', value='PRESS',
            ctrl=True, shift=True,
        )
        addon_keymaps.append((km, kmi))


def unregister_keymaps():
    for km, kmi in addon_keymaps:
        km.keymap_items.remove(kmi)
    addon_keymaps.clear()


# ---------------------------------------------------------------------------
# Registration
# ---------------------------------------------------------------------------

classes = (
    AxisLockProperties,
    AXISLOCK_OT_toggle,
    AXISLOCK_OT_configure_and_enable,
    AXISLOCK_PT_popover,
)


def register():
    for cls in classes:
        bpy.utils.register_class(cls)

    bpy.types.Scene.axis_lock_props = bpy.props.PointerProperty(
        type=AxisLockProperties
    )

    bpy.types.VIEW3D_HT_header.append(draw_header_button)

    bpy.app.handlers.depsgraph_update_pre.append(_pre_handler)
    bpy.app.handlers.depsgraph_update_post.append(_post_handler)

    register_keymaps()


def unregister():
    unregister_keymaps()

    if _pre_handler in bpy.app.handlers.depsgraph_update_pre:
        bpy.app.handlers.depsgraph_update_pre.remove(_pre_handler)
    if _post_handler in bpy.app.handlers.depsgraph_update_post:
        bpy.app.handlers.depsgraph_update_post.remove(_post_handler)

    bpy.types.VIEW3D_HT_header.remove(draw_header_button)

    del bpy.types.Scene.axis_lock_props

    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
