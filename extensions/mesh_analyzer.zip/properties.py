"""Scene settings. The per-check toggles are generated from the registry so
adding a check in checks.py is the only edit a new check needs."""

import bpy

from .visualization import heatmap
from .validation.checks import DESCRIPTIONS, SECTIONS


def _redraw(self, context):
    """Settings live on the scene, so nudge every 3D viewport to repaint."""
    for window in context.window_manager.windows:
        for area in window.screen.areas:
            if area.type == 'VIEW_3D':
                area.tag_redraw()


def _remode(self, context):
    """Each mode bakes a different scalar into the batches, so they go."""
    heatmap.invalidate()
    _redraw(self, context)


BAR_EMPTY = (0.18, 0.18, 0.18)


def _bar_getter(section_key):
    """Colour for one category's block of the score bar.

    Imports are deferred: `results` and `viewport_text` both reach back into
    the settings this module builds, so importing them at module scope would
    be circular.
    """
    def getter(self):
        from .validation.results import results, uid
        from .visualization.viewport_text import (
            section_color, COLOR_FAIL, COLOR_INFO)
        obj = bpy.context.active_object
        found = results.get(uid(obj)) if obj is not None else None
        if not found:
            return BAR_EMPTY
        checks = next(c for k, _t, _i, c in SECTIONS if k == section_key)
        color = section_color(found, self, checks)
        if color == COLOR_FAIL:
            return (0.90, 0.15, 0.10)
        if color == COLOR_INFO:
            return (0.95, 0.75, 0.10)
        return (0.25, 0.75, 0.30)

    return getter


def _range_guard(min_key, max_key):
    """Keep a min/max pair in order by pushing the other end along.

    Clamping the field being typed into would fight the user -- raising a
    minimum past the maximum is a normal way to move a whole range upward,
    and having the number snap back mid-edit reads as the field being
    broken. Carrying the other end instead always does what was asked.

    Writes go through `self[key]`, the raw ID-property, so setting one end
    does not re-fire the other's update callback and bounce between them.
    """
    def on_min(self, context):
        if getattr(self, min_key) > getattr(self, max_key):
            self[max_key] = getattr(self, min_key)
        _redraw(self, context)

    def on_max(self, context):
        if getattr(self, max_key) < getattr(self, min_key):
            self[min_key] = getattr(self, max_key)
        _redraw(self, context)

    return on_min, on_max


def _section_toggle(check_ids):
    """A master switch over one category's checks.

    Reads as on while *any* check in the category is on, so it reflects a
    partly-enabled category rather than claiming it is off; setting it drives
    every check in the category at once.
    """
    def getter(self):
        return any(getattr(self, f"enable_{cid}") for cid in check_ids)

    def setter(self, value):
        for cid in check_ids:
            setattr(self, f"enable_{cid}", value)

    return getter, setter


def _build_settings_class():
    annotations = {}

    for skey, title, _icon, checks in SECTIONS:
        annotations[f"show_{skey}"] = bpy.props.BoolProperty(default=True)
        for check_id, label, _fn in checks:
            # The description is the row's hover tooltip: what the check
            # looks for, why it matters, and what usually causes it. A name
            # alone does not say whether a result is a real problem or an
            # expected property of the asset.
            annotations[f"enable_{check_id}"] = bpy.props.BoolProperty(
                name=label, default=True,
                description=DESCRIPTIONS.get(
                    check_id, f"Include '{label}' in the check pass"),
            )
        getter, setter = _section_toggle([c[0] for c in checks])
        annotations[f"enable_section_{skey}"] = bpy.props.BoolProperty(
            name=title, get=getter, set=setter,
            description=f"Turn every '{title}' check on or off at once",
        )

    # One swatch per category for the score bar. A colour swatch is the only
    # panel widget that *stretches* -- icons are a fixed width, so a bar built
    # from them either has six small blocks or has to fake width by repeating
    # them. Read-only: the getter derives the colour from the last results, so
    # nothing has to be written during a draw.
    for skey, _title, _icon, _checks in SECTIONS:
        annotations[f"bar_{skey}"] = bpy.props.FloatVectorProperty(
            name="", size=3, subtype='COLOR_GAMMA', min=0.0, max=1.0,
            get=_bar_getter(skey),
        )

    annotations["budget_verts"] = bpy.props.IntProperty(
        name="Verts", default=10000, min=1, soft_max=1_000_000,
        description="Engine vertex budget. Counted the way an exporter "
                    "counts: every corner where the normal or a UV differs "
                    "is its own vertex, so seams, sharp edges and extra UV "
                    "sets all push this above Blender's vertex count",
    )
    # Ranges, not ceilings: one UV map is as wrong as five when the pipeline
    # expects two, and a mesh with no material slot reaches the engine with
    # nothing to draw it with.
    uv_min, uv_max = _range_guard("budget_uv_maps_min", "budget_uv_maps_max")
    annotations["budget_uv_maps_min"] = bpy.props.IntProperty(
        name="Min", default=1, min=0, soft_max=8, update=uv_min,
        description="Fewest UV layers this asset may have. One means a "
                    "missing UV map is a failure",
    )
    annotations["budget_uv_maps_max"] = bpy.props.IntProperty(
        name="Max", default=2, min=0, soft_max=8, update=uv_max,
        description="Most UV layers this asset may have. Each is a second "
                    "full set of UVs in the vertex buffer, and its seams "
                    "split vertices again",
    )
    mat_min, mat_max = _range_guard(
        "budget_materials_min", "budget_materials_max")
    annotations["budget_materials_min"] = bpy.props.IntProperty(
        name="Min", default=1, min=0, soft_max=32, update=mat_min,
        description="Fewest material slots this asset may have",
    )
    annotations["budget_materials_max"] = bpy.props.IntProperty(
        name="Max", default=1, min=0, soft_max=32, update=mat_max,
        description="Most material slots this asset may have. Engines cut "
                    "the mesh into one draw section per slot",
    )

    annotations["show_readout"] = bpy.props.BoolProperty(
        name="Validation", default=True,
        description="Show the active object's check results as text in the "
                    "viewport, below Blender's own overlay text",
        update=_redraw,
    )

    annotations["heatmap_enable"] = bpy.props.BoolProperty(
        name="Density Heatmap", default=False,
        description="Tint visible meshes by density (blue = light, "
                    "red = heavy). Drawn as an overlay -- meshes are never "
                    "modified",
        update=_redraw,
    )
    annotations["heatmap_mode"] = bpy.props.EnumProperty(
        name="Mode",
        items=(
            ("OBJECT", "Object",
             "One color per connected shell from its vert count relative to "
             "the scene -- a merged character still shows each attached "
             "piece (glasses, buttons...) individually"),
            ("VERTEX", "Vertex",
             "Per-vertex color from local edge density, normalised inside "
             "each mesh (decimated detail reads red, open flat areas blue)"),
            ("COST", "Cost",
             "Per-vertex color from how many vertices an engine has to "
             "split this one into: 1 where the surface is continuous, more "
             "at every seam, sharp edge and material boundary. Shows which "
             "verts are actually expensive to ship"),
            ("TEXEL", "Texel",
             "Per-face color from UV area vs 3D area, normalised across the "
             "scene: finds stretched UVs and texel density mismatch between "
             "assets. Meshes without UVs show dark grey"),
        ),
        default="OBJECT", update=_remode,
    )
    annotations["heatmap_auto_range"] = bpy.props.BoolProperty(
        name="Auto Range", default=True,
        description="Map the ramp across the lightest and heaviest visible "
                    "shell. Turn off to compare against fixed counts "
                    "(Object mode)",
        update=_redraw,
    )
    annotations["heatmap_range_min"] = bpy.props.IntProperty(
        name="Min", default=0, min=0, soft_max=1_000_000,
        description="Vertex count mapped to the cold end of the ramp",
        update=_redraw,
    )
    annotations["heatmap_range_max"] = bpy.props.IntProperty(
        name="Max", default=100_000, min=1, soft_max=10_000_000,
        description="Vertex count mapped to the hot end of the ramp",
        update=_redraw,
    )
    annotations["heatmap_show_legend"] = bpy.props.BoolProperty(
        name="Legend", default=True,
        description="Draw the color ramp, its range, a tick per visible "
                    "object and the scene average in the viewport corner",
        update=_redraw,
    )
    annotations["heatmap_texel_size"] = bpy.props.IntProperty(
        name="Texture Size", default=1024, min=1, soft_max=8192,
        description="Map size the texel-density legend is quoted against, so "
                    "the numbers read in px/cm the way artists budget them",
        update=_redraw,
    )

    return type(
        "MeshAnalyzerSettings",
        (bpy.types.PropertyGroup,),
        {"__annotations__": annotations},
    )


MeshAnalyzerSettings = _build_settings_class()
