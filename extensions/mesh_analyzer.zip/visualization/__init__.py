"""Visualization -- where the mesh spends its budget, drawn in the viewport.

The density/texel/cost heatmap and its legend (`heatmap`) and the overlay
text readout (`viewport_text`).

Everything here lives in Blender's Overlays popover rather than the sidebar:
these are things you leave switched on while you work, not things you press.
The readout is the deliberate overlap between the two modules -- it draws
`validation`'s results, so it imports from there.
"""

from . import heatmap, viewport_text  # noqa: F401
