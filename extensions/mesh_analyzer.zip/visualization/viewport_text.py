"""On-screen readout of the last check results, drawn in the 3D viewport.

Blender's own General Info / Statistics text is drawn in C with no Python hook,
so this cannot add lines inside that block. It draws its own block instead, in
the same pixel space, at the same font size and in the same theme colour, so it
reads as part of the viewport text rather than as a floating widget.
"""

import math

import blf
import bmesh
import bpy

from bpy.app.handlers import persistent

from ..validation.checks import SECTIONS, engine_vertex_split
from ..validation.results import is_enabled, results, uid

_handle = None

FONT_POINTS = 11.0
COLUMN_GAP = 12.0      # unscaled px between the label and its value
SECTION_GAP = 7.0      # unscaled px of air between one category and the next
# How far the block rides above the native block's next free line. Zero puts
# the pinned Engine Verts row exactly one statistics-row pitch below
# Triangles, so it reads as one more statistic rather than a separate block.
READOUT_LIFT = 0.0

# --- geometry of Blender's own top-left text block ------------------------
# Blender composes that block in C and exposes neither its height nor its
# line height, so these were measured off screenshots of a real viewport:
# red calibration bars were drawn from a POST_PIXEL handler at known
# region-relative heights, and every native line was located against them,
# across UI scales 1.5-3.0 and every combination of the Text overlays.
# All values are pixels at ui_scale 1.0; multiply by the scale in use.
#
# Three separate overlays feed that column -- General Info, Performance and
# Statistics -- and they are NOT spaced alike: Performance opens with a full
# blank line, Statistics with roughly half of one. Treating them as one
# uniform stack is what made the gap wander as overlays were toggled.
NATIVE_LINE = 17.34        # pitch between statistics / performance rows
NATIVE_TEXT_LINE = 17.77   # pitch between the view-name / object-info lines,
                           # which Blender spaces very slightly wider
NATIVE_TOP = 64.0          # ink top of the first line, from the region top
NATIVE_PERF_GAP = 17.34    # blank space before Performance -- a whole line
NATIVE_STATS_GAP = 10.0    # blank space before Statistics -- about half
NATIVE_LEFT = 10.3         # left inset Blender draws its text at
NATIVE_PERF_ROWS = 3       # Evaluation, Synchronization, Total

# Statistics rows per mode. Object and Edit Mode on a mesh show Objects,
# Vertices, Edges, Faces and Triangles; the other modes report less.
_ROWS_BY_MODE = {
    'SCULPT': 3,                 # Objects, Vertices, Faces
    'PAINT_VERTEX': 1,
    'PAINT_WEIGHT': 1,
    'PAINT_TEXTURE': 1,
    'PAINT_GPENCIL': 1,
    'POSE': 2,                   # Objects, Bones
    'EDIT_ARMATURE': 3,
}
# Active-object types that add the four geometry rows. Curves, surfaces and
# metaballs do not, even though they evaluate to geometry -- measured, not
# assumed.
_GEOMETRY_TYPES = {'MESH', 'FONT', 'GPENCIL', 'GREASEPENCIL'}

COLOR_PASS = (0.42, 0.82, 0.45, 1.0)
COLOR_FAIL = (1.00, 0.36, 0.30, 1.0)
COLOR_INFO = (0.96, 0.78, 0.30, 1.0)


def stats_rows(context):
    """How many rows Blender's Statistics block is showing right now.

    Driven by the *active* object, not by what the scene contains: a scene
    full of meshes with nothing active still reports a single Objects row.
    """
    rows = _ROWS_BY_MODE.get(context.mode)
    if rows is not None:
        return rows
    obj = context.active_object
    if obj is None:
        return 1
    if obj.type in _GEOMETRY_TYPES:
        return 5
    if obj.type == 'LIGHT':
        return 2                 # Objects, Lights
    return 1


def shows_grid_unit(context):
    """Is Blender drawing its grid-unit line ("10 Centimeters") right now?

    It is a third General Info line, and its condition in `view3d_draw.cc` is
    `!rv3d->is_persp && RV3D_VIEW_IS_AXIS(rv3d->view)` -- orthographic *and*
    looking straight down an axis. A tumbled orthographic view does not get
    it, so testing the projection alone would over-count by a line.

    Python has no `rv3d->view` enum, so axis alignment is measured from the
    view matrix: every basis row is a signed unit axis.
    """
    rv3d = context.region_data
    if rv3d is None or rv3d.is_perspective:
        return 0
    for row in rv3d.view_matrix.to_3x3():
        magnitudes = sorted(abs(c) for c in row)
        if magnitudes[2] < 0.9999 or magnitudes[1] > 1e-4:
            return 0
    return 1


def native_block_bottom(context):
    """Region-relative y (measured down from the top) where our readout's
    first line belongs, in ink-top terms.

    Walks the same three overlays Blender stacks, in the same order, each
    with its own leading gap.
    """
    scale = context.preferences.system.ui_scale or 1.0
    overlay = context.space_data.overlay
    view = context.preferences.view

    y = NATIVE_TOP * scale

    if overlay.show_text:
        lines = bool(view.show_view_name) + bool(view.show_object_info)
        lines += shows_grid_unit(context)
        y += lines * NATIVE_TEXT_LINE * scale

    if getattr(overlay, "show_performance", False):
        y += (NATIVE_PERF_GAP + NATIVE_PERF_ROWS * NATIVE_LINE) * scale

    if overlay.show_stats:
        y += (NATIVE_STATS_GAP + stats_rows(context) * NATIVE_LINE) * scale

    # With nothing above it the readout starts at NATIVE_TOP -- the same line
    # Blender's own first row would occupy. No leading gap: it is the top of
    # the column, not a block appended to one.
    return y

# blf.shadow level 6 is the outline mode Blender's own viewport text uses;
# 0/3/5 are the blur modes. Present in 4.2 and 5.x alike.
SHADOW_OUTLINE = 6


def _grayscale(rgb):
    """Blender's srgb_to_grayscale: Rec.709 luma over sRGB values."""
    return 0.2126 * rgb[0] + 0.7152 * rgb[1] + 0.0722 * rgb[2]


def background_color(context):
    """The viewport's background, whichever source is driving it."""
    shading = context.space_data.shading
    kind = getattr(shading, "background_type", 'THEME')
    if kind == 'VIEWPORT':
        return tuple(shading.background_color)
    if kind == 'WORLD':
        world = context.scene.world
        if world is not None:
            return tuple(world.color)
    theme = context.preferences.themes[0].view_3d.space
    return tuple(theme.gradients.high_gradient)


def outline_for(color):
    """Blender's outline rule: black behind light text, white behind dark.

    Applied per drawn colour, not once for the block. The status colours are
    fixed -- they have to stay green/red/amber to mean anything -- so they
    need the outline judged on themselves. Sharing the body text's outline
    put a white halo round green `OK` the moment the background went light.
    """
    shade = 0.0 if _grayscale(color) > 0.4 else 1.0
    return (shade, shade, shade, 0.8)


def text_colors(context):
    """(text, shadow) RGBA, by Blender's own rule for its viewport text.

    Ported from `ED_view3d_text_colors_get`: start from the theme's
    highlighted text colour, and if it sits too close to the background,
    push it away -- darken a light colour, brighten a dark one. The outline
    then goes black or white, whichever the text is not, so the text stays
    legible against any background instead of dissolving into it.
    """
    text = list(context.preferences.themes[0].view_3d.space.text_hi)[:3]
    bg = background_color(context)

    distance = math.sqrt(sum((t - b) ** 2 for t, b in zip(text, bg)))
    if distance < 0.5:
        factor = 0.33 if _grayscale(text) > 0.5 else 3.0
        text = [min(max(c * factor, 0.0), 1.0) for c in text]

    return (*text, 1.0), outline_for(text)


def _status(result):
    """(value text, colour key) for one check result."""
    if result.get("skipped"):
        return "-", None
    count = result["count"]
    if count == -1:
        return "error", COLOR_FAIL
    if count == 0:
        # A check that measured something worth seeing even when it passed --
        # the budgets -- says so instead of a bare OK.
        return result.get("note") or "OK", COLOR_PASS
    if result.get("info"):
        return f"{count:,}", COLOR_INFO
    detail = result.get("detail")
    return (detail if detail else f"{count:,}"), COLOR_FAIL


HEADER = "header"
CHECK = "check"
STAT = "stat"

# session_uid -> (total, splits). `splits` is the engine vertex count for each
# *base* vertex, which is what makes an Edit-Mode selection cheap to price:
# selected engine verts is just a masked sum, no recount.
#
# Recomputing the split itself costs a np.unique over every loop, so it is
# cached: session_uid -> (fingerprint, (total, splits)). The fingerprint is
# re-checked on every read, which is what makes the cache safe rather than
# merely fast -- see `_fingerprint`.
_engine_cache = {}
# session_uid -> (selection signature, engine verts selected). Selection does
# not change the split, only which part of it is picked, so the expensive
# walk runs when the selection actually changes rather than every redraw.
_selection_cache = {}
# Objects seen in Edit Mode, so the first update after they leave it can force
# a recount even when the fingerprint is unchanged.
_editing = set()


def live_counts(obj):
    """(verts, edges, faces) of the geometry as it stands right now.

    In Edit Mode the mesh datablock still holds the *pre-edit* topology --
    the live one is in the edit bmesh -- so anything built without leaving
    the mode is invisible to `obj.data`. Both are O(1) struct reads.
    """
    if obj.mode == 'EDIT':
        try:
            bm = bmesh.from_edit_mesh(obj.data)
            return len(bm.verts), len(bm.edges), len(bm.faces)
        except (RuntimeError, ValueError, AttributeError):
            pass
    mesh = obj.data
    return len(mesh.vertices), len(mesh.edges), len(mesh.polygons)


def _fingerprint(obj):
    """Cheap stamp identifying what the cached count was measured from.

    All O(1) collection lengths, so this is free to check on every redraw.

    It exists because the depsgraph alone cannot be trusted to invalidate:
    geometry updates are ignored while an object is in Edit Mode (recounting
    a dense mesh on every mouse move would make the viewport crawl), and the
    update that arrives on the way out does not always carry the geometry
    flag. Model a plane up into a full asset without leaving Edit Mode and
    the count would otherwise stay pinned at the primitive's four vertices.

    Taking the element counts live rather than off the datablock is what
    makes the number move *while* you model: extruding or deleting changes
    them, so the count refreshes on the edit itself, whereas dragging a
    vertex leaves them alone -- and dragging a vertex cannot change how many
    vertices an engine receives, so there is nothing to recount.
    """
    mesh = obj.data
    colors = mesh.color_attributes
    return (live_counts(obj),
            len(mesh.uv_layers), len(obj.material_slots),
            # Colour layers split corners too, and adding one changes none of
            # the lengths above -- the mesh keeps exactly the same topology.
            len(colors), colors.render_color_index,
            # The modifier stack, because a modifier can change what ships
            # without moving a single count on the base mesh: UV Project and
            # Geometry Nodes both add UV layers that way. Cheap -- meshes
            # have a handful of modifiers, not thousands.
            tuple((m.type, m.show_viewport) for m in obj.modifiers))


def engine_verts(obj):
    """(total, splits, uv_maps, materials) for `obj`, cached; None if no mesh.

    All four come off the same evaluated mesh, so modifiers count -- the same
    numbers the checks report -- and one `to_mesh()` serves the lot rather
    than one per row. UV layers and material slots are read here rather than
    off `obj.data` precisely so a modifier that adds either (UV Project,
    Geometry Nodes) shows up, which is the whole point of measuring what
    ships.

    `splits` is indexed by base vertex, so it is only meaningful when the
    evaluated mesh still has the base topology; when a modifier changes the
    vertex count it comes back empty and the Edit-Mode split is not offered.
    """
    key = uid(obj)
    stamp = _fingerprint(obj)
    cached = _engine_cache.get(key)
    if cached is not None and cached[0] == stamp:
        return cached[1]

    depsgraph = bpy.context.evaluated_depsgraph_get()
    evaluated = obj.evaluated_get(depsgraph)
    try:
        mesh = evaluated.to_mesh()
    except RuntimeError:
        return None
    if mesh is None:
        return None
    try:
        total, splits = engine_vertex_split(mesh)
        # Live count, not `obj.data`: in Edit Mode the datablock is stale, so
        # comparing against it would drop the per-vertex splits on every
        # edited mesh and take the selected/total readout with them.
        if len(splits) != live_counts(obj)[0]:
            splits = None          # modifiers changed the topology
        uv_maps = len(mesh.uv_layers)
        # Slots can be linked to the object rather than the mesh data, and
        # those still reach the exporter -- same fallback the check uses.
        materials = len(mesh.materials) or len(obj.material_slots)
    finally:
        evaluated.to_mesh_clear()

    # The stale entry's selection tally was priced against the old split.
    _selection_cache.pop(key, None)
    facts = (total, splits, uv_maps, materials)
    _engine_cache[key] = (stamp, facts)
    return facts


def _selected_engine_verts(obj, splits):
    """Engine verts belonging to the selected vertices, in Edit Mode.

    `count_selected_items()` is a cheap C-side call and changes whenever the
    selection does, which makes it a good cache key: the costly part --
    reading which vertices are selected out of the edit-mode bmesh, one
    Python attribute at a time -- then runs once per selection change rather
    than once per redraw.
    """
    if splits is None:
        return None
    key = uid(obj)
    try:
        signature = tuple(obj.data.count_selected_items())
    except (AttributeError, RuntimeError):
        return None

    cached = _selection_cache.get(key)
    if cached is not None and cached[0] == signature:
        return cached[1]

    try:
        bm = bmesh.from_edit_mesh(obj.data)
    except (RuntimeError, ValueError):
        return None
    if len(bm.verts) != len(splits):
        return None
    total = 0
    for index, vert in enumerate(bm.verts):
        if vert.select:
            total += int(splits[index])

    _selection_cache[key] = (signature, total)
    return total


def _result_color(found, check_id):
    """Status colour for a check, or None until the mesh is validated."""
    result = (found or {}).get(check_id)
    if result is None or result.get("skipped"):
        return None
    if result["count"] == -1 or (result["count"] > 0
                                 and not result.get("info")):
        return COLOR_FAIL
    return COLOR_INFO if result["count"] else COLOR_PASS


def stat_rows(obj, prefs, found):
    """The pinned statistics: what the asset costs, always on screen.

    Only the active object is measured. Summing every visible mesh was the
    honest reading of "selected / visible" but it priced the whole scene on
    every redraw, which is far too much work for a line of text.

    Object Mode reads `count / budget`; Edit Mode switches to
    `selected / total` inside the edited mesh, which is what you want while
    you are picking geometry apart.

    With nothing selected in Object Mode every row reads 0, matching the
    block above -- Blender's own statistics go to `0 / n` there, and an
    object can stay active after a deselect-all, so quoting its counts would
    have this block disagree with the one it sits under.
    """
    if obj.mode == 'OBJECT' and not obj.select_get():
        return [(STAT, label, "0", None)
                for label in ("GPU Verts", "UV Maps", "Materials")]

    entry = engine_verts(obj)
    if entry is None:
        return []
    total, splits, uv_maps, materials = entry

    if obj.mode == 'EDIT':
        selected = _selected_engine_verts(obj, splits)
        value = f"{total:,}" if selected is None \
            else f"{selected:,} / {total:,}"
    elif found and found.get("vert_budget"):
        # The limit only joins the number once it has actually been checked
        # against; before that it is a measurement, not a verdict.
        value = f"{total:,} / {prefs.budget_verts:,}"
    else:
        value = f"{total:,}"

    rows = [(STAT, "GPU Verts", value, _result_color(found, "vert_budget"))]

    # These three are *statistics*, so they track the mesh continuously --
    # the count always comes from the evaluated mesh measured just now, never
    # from the stored result. Reading it out of `found` froze the rows the
    # moment you validated, while GPU Verts beside them carried on updating.
    # Validating only adds the limit and the colour, and both are judged
    # against the live number so they cannot contradict it.
    checked = bool(found)
    for check_id, label, count, low, high in (
        ("uv_maps", "UV Maps", uv_maps,
         prefs.budget_uv_maps_min, prefs.budget_uv_maps_max),
        ("materials", "Materials", materials,
         prefs.budget_materials_min, prefs.budget_materials_max),
    ):
        shown = str(count)
        color = None
        if checked and found.get(check_id) is not None:
            limit = str(low) if low == high else f"{low}-{high}"
            shown = f"{shown} / {limit}"
            color = COLOR_FAIL if (count < low or count > high) else COLOR_PASS
        rows.append((STAT, label, shown, color))
    return rows


def section_color(found, prefs, checks):
    """Green all clear, amber if only informational counts, red on a failure.

    The header carries the category's worst state, so the block can be read
    at a glance without going row by row.
    """
    worst = COLOR_PASS
    for check_id, _label, _fn in checks:
        if not is_enabled(prefs, check_id):
            continue
        result = found.get(check_id)
        if result is None or result.get("skipped"):
            continue
        count = result["count"]
        if count == -1 or (count > 0 and not result.get("info")):
            return COLOR_FAIL
        if count > 0:
            worst = COLOR_INFO
    return worst


def section_tally(found, prefs, checks):
    """(passing, applicable) for one category.

    Checks that could not run -- no UV map for the UV checks -- are left out
    of both halves rather than counted as failures, so the tally never blames
    a mesh for a check that never applied.
    """
    passing = applicable = 0
    for check_id, _label, _fn in checks:
        if not is_enabled(prefs, check_id):
            continue
        result = found.get(check_id)
        if result is None or result.get("skipped"):
            continue
        applicable += 1
        if result.get("info") or result["count"] == 0:
            passing += 1
    return passing, applicable


def readout_rows(obj, found, prefs, with_stats=True, with_checks=True):
    """(kind, label, value, value_colour_or_None) rows, grouped by category.

    Every enabled check is listed with its state -- passes included -- so the
    readout is a full verdict rather than only a list of complaints, and the
    grouping matches the sidebar so the two read the same way.

    There is no total line: the failures are right there in red, and a
    "6 FAILED" banner on top of them only says it again, louder.

    The object name is deliberately absent too: pipeline names run long enough
    to push the block across the viewport, and Blender's own text already
    names the active object directly above this.
    """
    # `found` is None until the mesh has been validated; the pinned stats
    # still draw, so normalise rather than bailing out.
    found = found or {}

    rows = list(stat_rows(obj, prefs, found)) if with_stats else []
    if not with_checks:
        return rows

    for skey, title, _icon, checks in SECTIONS:
        # Budget is already the pinned block at the top; repeating it as a
        # category would print the same three numbers twice.
        if skey == "budget":
            continue
        listed = []
        for check_id, label, _fn in checks:
            if not is_enabled(prefs, check_id):
                continue
            result = found.get(check_id)
            if result is None:
                continue
            value, color = _status(result)
            listed.append((CHECK, label, value, color))
        if not listed:
            continue
        passing, applicable = section_tally(found, prefs, checks)
        color = section_color(found, prefs, checks) if found else None
        rows.append((HEADER, f"{title} ({passing}/{applicable})", "", color))
        rows.extend(listed)
    return rows


def draw():
    context = bpy.context
    space = context.space_data
    if space is None or space.type != 'VIEW_3D':
        return
    if not space.overlay.show_overlays:
        return

    prefs = getattr(context.scene, "meshan_settings", None)
    if prefs is None:
        return

    # The pinned GPU Verts / UV Maps / Materials rows belong to Statistics:
    # they are counts of what the object is made of, so they follow Blender's
    # own Statistics toggle and continue the block they sit under. The
    # Validation toggle governs the check list -- and only then do the pinned
    # rows take their status colour and show their budgets.
    with_stats = bool(context.space_data.overlay.show_stats)
    with_checks = bool(prefs.show_readout)
    if not (with_stats or with_checks):
        return

    obj = context.active_object
    if obj is None or obj.type != 'MESH':
        return
    # No early exit on an unvalidated mesh: the pinned rows are measurements,
    # not verdicts, and stay visible whether or not the checks have been run.
    found = results.get(uid(obj)) if with_checks else None

    region = context.region
    if region is None:
        return

    scale = context.preferences.system.ui_scale or 1.0
    font = 0
    blf.size(font, FONT_POINTS * scale)
    line_height = NATIVE_LINE * scale

    rows = readout_rows(obj, found, prefs, with_stats, with_checks)
    if not rows:
        return
    # Everything that is not a status value takes the theme's colour, exactly
    # as Blender's own viewport text does -- headers included. The grouping is
    # carried by the tallies and the gap between categories, not by a
    # second-class colour.
    text_color, text_shadow = text_colors(context)

    # The same outline Blender puts on its own viewport text: it is what keeps
    # the block readable over a bright model or a light background, where flat
    # text would wash out. Level 6 is outline; 0/3/5 are blurs.
    blf.enable(font, blf.SHADOW)
    blf.shadow_offset(font, 0, 0)

    # Continue Blender's own column: same left inset, same line pitch, and
    # the first row one line below wherever its block ends. The block's
    # height follows the Text overlays, so toggling one shifts this with it
    # instead of leaving a gap that grows and shrinks.
    x = NATIVE_LEFT * scale
    # Two columns, because the block has two jobs. The pinned statistics
    # continue Blender's own list, so they take Blender's column, sized to
    # its longest row, "Triangles". The checks are a separate list with much
    # longer names, so they get their own -- forcing those into Blender's
    # column would either truncate them or push every number across the view.
    stat_x = x + max(
        [blf.dimensions(font, "Triangles")[0]]
        + [blf.dimensions(font, label)[0] for kind, label, _v, _c in rows
           if kind == STAT]
    ) + COLUMN_GAP * scale
    check_x = x + max(
        [0.0] + [blf.dimensions(font, label)[0]
                 for kind, label, _v, _c in rows if kind == CHECK]
    ) + COLUMN_GAP * scale

    # blf positions a baseline; the model is in ink tops, so drop by the cap
    # height to line our capitals up with Blender's.
    cap = blf.dimensions(font, "H")[1]
    y = region.height - (native_block_bottom(context) + cap
                         - READOUT_LIFT * scale)

    for i, (kind, label, value, color) in enumerate(rows):
        if kind == HEADER and i:
            # A little air before each new category -- less than a blank line,
            # which left the block looking gappy and twice as tall as it is.
            y -= SECTION_GAP * scale
        if y < 0:
            break
        # Category headers carry their own worst-state colour; everything
        # else shares the left edge and the theme colour.
        head = color if kind == HEADER and color else text_color
        blf.shadow(font, SHADOW_OUTLINE, *(
            outline_for(head[:3]) if head is not text_color else text_shadow))
        blf.color(font, *head)
        blf.position(font, x, y, 0.0)
        blf.draw(font, label)
        if value:
            shown = color if color else text_color
            blf.shadow(font, SHADOW_OUTLINE, *outline_for(shown[:3]))
            blf.color(font, *shown)
            blf.position(font, stat_x if kind == STAT else check_x, y, 0.0)
            blf.draw(font, value)
        y -= line_height

    # blf state is global and font 0 is Blender's own; leaving the shadow on
    # would put an outline round every other bit of text drawn after us.
    blf.disable(font, blf.SHADOW)


def tag_redraw():
    """Repaint every 3D viewport -- results changed underneath the readout."""
    for window in bpy.context.window_manager.windows:
        for area in window.screen.areas:
            if area.type == 'VIEW_3D':
                area.tag_redraw()


@persistent
def _on_depsgraph_update(scene, depsgraph):
    """Drop cached counts for geometry that changed.

    Deliberately not while the object is in Edit Mode: every mouse move there
    fires a geometry update, and recounting a dense mesh per frame would make
    the viewport crawl. The last count stays on screen during the edit and
    refreshes when the mode change fires its own update.
    """
    for update in depsgraph.updates:
        id_block = update.id
        if not isinstance(id_block, bpy.types.Object):
            continue
        # `.original`, not the update's own id: a depsgraph update carries the
        # *evaluated* copy, whose session_uid is 0 rather than the object's.
        # Keying the caches off that pops a slot nothing is ever stored under,
        # which silently turns the whole handler into a no-op.
        key = id_block.original.session_uid
        if id_block.mode == 'EDIT':
            _editing.add(key)
            continue

        # Leaving Edit Mode always recounts, whatever the update claims. An
        # edit can change the count without changing anything the fingerprint
        # can see -- re-unwrapping moves UVs, marking an edge sharp moves
        # normals, neither touches a single length -- and the update that
        # arrives on the way out does not reliably carry the geometry flag.
        was_editing = key in _editing
        _editing.discard(key)
        if not (was_editing or update.is_updated_geometry):
            continue
        _engine_cache.pop(key, None)
        _selection_cache.pop(key, None)


@persistent
def _on_load(_file):
    _engine_cache.clear()
    _selection_cache.clear()
    _editing.clear()


def register():
    global _handle
    _handle = bpy.types.SpaceView3D.draw_handler_add(
        draw, (), 'WINDOW', 'POST_PIXEL')
    bpy.app.handlers.depsgraph_update_post.append(_on_depsgraph_update)
    bpy.app.handlers.load_post.append(_on_load)


def unregister():
    global _handle
    if _on_load in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.remove(_on_load)
    if _on_depsgraph_update in bpy.app.handlers.depsgraph_update_post:
        bpy.app.handlers.depsgraph_update_post.remove(_on_depsgraph_update)
    if _handle is not None:
        bpy.types.SpaceView3D.draw_handler_remove(_handle, 'WINDOW')
        _handle = None
    _engine_cache.clear()
    _selection_cache.clear()
    _editing.clear()
