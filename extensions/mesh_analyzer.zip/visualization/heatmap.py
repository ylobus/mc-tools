"""Density heatmap drawn as a viewport overlay.

Merged in from the standalone Vertex Heatmap tool, which owns the drawing
approach: a blended color pass over the visible surface of each mesh, the way
the Face Orientation overlay tints by normal direction. Nothing is written to
the meshes -- no color attribute, no shading-mode change -- so toggling it off
leaves the file exactly as it was, and saving with it on saves nothing extra.

Three modes share one shader. Each vertex carries a raw scalar; the ramp and
its normalisation happen on the GPU, so changing range, opacity or log scale
costs a redraw rather than a rebuild:

  OBJECT  the vert count of the connected shell each vertex belongs to, so a
          merged character still resolves into glasses, buttons, shoes...
  VERTEX  local edge density (inverse mean incident edge length), normalised
          inside each mesh so every object shows its own densest spots.
  TEXEL   UV area vs 3D area per UV shell, normalised across the whole scene
          so texel mismatch *between* assets shows up, not just within one.
"""

import math

import blf
import bpy
import gpu
import numpy as np
from bpy.app.handlers import persistent
from gpu_extras.batch import batch_for_shader

from ..validation.checks import engine_vertex_split

_surface_handle = None
_legend_handle = None
_shader = None

# session_uid -> _Entry. Invalidated per-object on geometry updates.
#
# Keyed by uid rather than name: names are mutable and reusable, so renaming
# an object orphaned its entry, and a name freed by one object and taken by
# another handed the second one the first one's geometry.
_cache = {}

# Range and mode of the last surface pass, so the legend matches what was drawn.
_last_range = (0.0, 1.0)
_last_mode = "OBJECT"
# (representative value, object name) per visible object, and their mean --
# the legend's tick marks and average dot.
_last_ticks = []
_last_avg = None

# Cold -> hot. Blue / cyan / green / amber / red reads as "light -> heavy".
RAMP = (
    (0.10, 0.28, 0.85),
    (0.10, 0.75, 0.85),
    (0.25, 0.80, 0.25),
    (0.95, 0.75, 0.10),
    (0.90, 0.15, 0.10),
)

# Texel mode, mesh without a UV map: nothing to say, so say nothing loudly.
NO_DATA_COLOR = (0.18, 0.18, 0.18)

# Blend strength of the tint over the shaded surface. Fixed: the useful range
# is narrow, and 0.75 reads the colour clearly while the form still shows.
OPACITY = 0.75

# No depth offset. This is what Blender's own Face Orientation overlay does
# (DRW_STATE_DEPTH_LESS_EQUAL, no bias): re-draw the same surface and let it
# tie with the depth already there.
#
# It only became possible once the vertex transform was reassociated to
# Projection * (View * (Model * pos)) -- Blender's own order. The old
# ViewProjection * (Model * pos) rounded differently in the last bits, tore
# the tint into speckle, and needed an offset to paper over it; that offset
# was in turn what let the tint bleed through geometry in front of it. With
# the orders matched, measured silhouette coverage is identical at 0.997
# with and without the offset, so the offset is pure downside.
#
# Left as a dial rather than deleted: if some driver ever rounds differently
# and the tint speckles, a value around 0.0005 restores it at the cost of a
# little bleed.
DEPTH_OFFSET = 0.0
DEPTH_TEST = 'LESS_EQUAL'


class _Entry:
    """A cached drawable: the batch, its value range, and the distinct values
    the object contributes to the legend -- one per part it resolves into."""

    __slots__ = ("batch", "vmin", "vmax", "has_data", "parts", "mean")

    def __init__(self, batch, vmin, vmax, has_data, parts=(), mean=None):
        self.batch = batch
        self.vmin = vmin
        self.vmax = vmax
        self.has_data = has_data
        self.parts = tuple(parts)
        # This object's own average, in whatever the mode measures. The
        # legend's average mark reads the *selected* object rather than the
        # scene, so it answers "where does this asset sit" -- which is the
        # question you are asking with an object picked.
        self.mean = mean


# ---------------------------------------------------------------------------
# Shader
# ---------------------------------------------------------------------------

# Blender transforms a vertex as Projection * (View * (Model * pos)). Folding
# matrices together on the CPU -- which the builtin shaders do -- rounds
# differently in the last bits, and against a depth buffer filled by the solid
# pass that tears the tint into dashes. Matching the association order lands us
# on the same values.
_VERTEX_SOURCE = """
void main()
{
  /* Slide the surface a hair toward the viewer so it wins the depth test
     against the solid pass it is copying.

     Done in VIEW space, not world space. The camera sits at the origin
     there, so the numbers are small and the subtraction keeps its precision.
     The world-space version -- viewer.xyz - world_pos.xyz -- looks equivalent
     and is not: put an object 10,000 units from the origin and those are big
     float32 values whose difference has lost the low bits, so the offset
     collapses and the tint tears. Every scene that is not centred on the
     origin hits that, which is most of them.

     Perspective: scale xyz, so the vertex travels along its own view ray and
     x/z and y/z are unchanged -- the silhouette does not move.
     Orthographic: rays are parallel to view -Z, so only z moves; x and y do
     not enter the projection's depth at all.

     A constant bias in clip space was the other candidate and is worse:
     normalised depth is so non-linear that one constant is a sliver near the
     camera and metres out at the far plane, where it punches through walls. */
  vec4 view_pos = ViewMatrix * (ModelMatrix * vec4(pos, 1.0));
  if (is_perspective != 0) {
    view_pos.xyz *= (1.0 - depth_offset);
  }
  else {
    view_pos.z += abs(view_pos.z) * depth_offset;
  }

  float x = val, l = lo, h = hi;
  if (log_scale != 0) {
    x = log2(max(x, 1.0));
    l = log2(max(l, 1.0));
    h = log2(max(h, 1.0));
  }
  v_t = (h > l) ? clamp((x - l) / (h - l), 0.0, 1.0) : 0.5;

  gl_Position = ProjectionMatrix * view_pos;
}
"""

_FRAGMENT_SOURCE = """
vec3 heat_ramp(float t)
{
  t = clamp(t, 0.0, 1.0) * 4.0;
  if (t < 1.0) { return mix(RAMP0, RAMP1, t); }
  if (t < 2.0) { return mix(RAMP1, RAMP2, t - 1.0); }
  if (t < 3.0) { return mix(RAMP2, RAMP3, t - 2.0); }
  return mix(RAMP3, RAMP4, t - 3.0);
}

void main()
{
  vec3 rgb = (no_data != 0) ? NO_DATA_RGB : heat_ramp(v_t);
  fragColor = vec4(rgb, OPACITY);
}
"""


def _glsl_vec3(rgb):
    return "vec3({:.6f}, {:.6f}, {:.6f})".format(*rgb)


def _get_shader():
    """Built on first draw -- shader creation needs a live GPU context."""
    global _shader
    if _shader is not None:
        return _shader

    defines = "".join(
        "#define RAMP{} {}\n".format(i, _glsl_vec3(c))
        for i, c in enumerate(RAMP)
    )
    defines += "#define NO_DATA_RGB {}\n".format(_glsl_vec3(NO_DATA_COLOR))
    defines += "#define OPACITY {:.6f}\n".format(OPACITY)

    iface = gpu.types.GPUStageInterfaceInfo("mc_heat_interface")
    iface.smooth('FLOAT', "v_t")

    info = gpu.types.GPUShaderCreateInfo()
    info.push_constant('MAT4', "ModelMatrix")
    info.push_constant('MAT4', "ViewMatrix")
    info.push_constant('MAT4', "ProjectionMatrix")
    info.push_constant('FLOAT', "depth_offset")
    info.push_constant('FLOAT', "lo")
    info.push_constant('FLOAT', "hi")
    info.push_constant('INT', "log_scale")
    info.push_constant('INT', "is_perspective")
    info.push_constant('INT', "no_data")
    info.vertex_in(0, 'VEC3', "pos")
    info.vertex_in(1, 'FLOAT', "val")
    info.vertex_out(iface)
    info.fragment_out(0, 'VEC4', "fragColor")
    info.vertex_source(defines + _VERTEX_SOURCE)
    info.fragment_source(defines + _FRAGMENT_SOURCE)

    _shader = gpu.shader.create_from_info(info)
    return _shader


def ramp_color(t):
    """Sample RAMP at t in [0, 1] on the CPU, for the legend."""
    t = min(max(t, 0.0), 1.0) * (len(RAMP) - 1)
    i = min(int(t), len(RAMP) - 2)
    f = t - i
    lo, hi = RAMP[i], RAMP[i + 1]
    return tuple(lo[c] + (hi[c] - lo[c]) * f for c in range(3))


# ---------------------------------------------------------------------------
# Per-mode values
# ---------------------------------------------------------------------------

def robust_range(values):
    """5th..95th percentile -- a couple of spikes must not flatten the ramp."""
    if len(values) == 0:
        return 0.0, 1.0
    lo, hi = np.percentile(values, [5.0, 95.0])
    return float(lo), float(hi)


def vertex_density(mesh):
    """Per-vertex inverse mean incident edge length. Short edges read hot."""
    n = len(mesh.vertices)
    ne = len(mesh.edges)
    if n == 0 or ne == 0:
        return np.zeros(n, dtype=np.float32)

    co = np.empty(n * 3, dtype=np.float32)
    mesh.vertices.foreach_get("co", co)
    co = co.reshape(-1, 3)
    ev = np.empty(ne * 2, dtype=np.int32)
    mesh.edges.foreach_get("vertices", ev)
    ev = ev.reshape(-1, 2)

    lengths = np.linalg.norm(co[ev[:, 0]] - co[ev[:, 1]], axis=1)
    sums = np.zeros(n, dtype=np.float64)
    counts = np.zeros(n, dtype=np.int32)
    np.add.at(sums, ev[:, 0], lengths)
    np.add.at(sums, ev[:, 1], lengths)
    np.add.at(counts, ev[:, 0], 1)
    np.add.at(counts, ev[:, 1], 1)

    linked = counts > 0
    mean = np.ones(n, dtype=np.float64)
    mean[linked] = sums[linked] / counts[linked]
    density = 1.0 / np.maximum(mean, 1e-9)
    density[~linked] = 0.0
    return density.astype(np.float32)


def shell_sizes(mesh):
    """Vert count of each vertex's connected shell, via union-find on edges."""
    n = len(mesh.vertices)
    if n == 0:
        return np.zeros(0, dtype=np.float32)

    parent = list(range(n))

    def find(x):
        root = x
        while parent[root] != root:
            root = parent[root]
        while parent[x] != root:  # path compression
            parent[x], x = root, parent[x]
        return root

    ne = len(mesh.edges)
    if ne:
        ev = np.empty(ne * 2, dtype=np.int32)
        mesh.edges.foreach_get("vertices", ev)
        for a, b in ev.reshape(-1, 2).tolist():
            ra, rb = find(a), find(b)
            if ra != rb:
                parent[rb] = ra

    roots = np.fromiter((find(i) for i in range(n)), dtype=np.int64, count=n)
    counts = np.bincount(roots, minlength=n)
    return counts[roots].astype(np.float32)


UV_WELD_EPS = 1e-6


def _uv_shell_of_face(mesh, uv, starts, totals, nl, nf):
    """Shell (UV island) id per face.

    Two faces belong to the same shell when they share an edge *and* their UVs
    agree along it -- a seam, or any UV discontinuity, splits them. Union-find
    over the matching edge pairs, same as the geometric shell detection.
    """
    loop_verts = np.empty(nl, dtype=np.int32)
    mesh.loops.foreach_get("vertex_index", loop_verts)

    idx = np.arange(nl)
    nxt = idx + 1
    nxt[starts + totals - 1] = starts

    v0, v1 = loop_verts[idx], loop_verts[nxt]
    swap = v0 > v1
    lo = np.where(swap, v1, v0).astype(np.int64)
    hi = np.where(swap, v0, v1).astype(np.int64)
    # UVs ordered to match the normalised vertex pair, so the two sides of an
    # edge are directly comparable despite their opposite winding.
    uv_lo = np.where(swap[:, None], uv[nxt], uv[idx])
    uv_hi = np.where(swap[:, None], uv[idx], uv[nxt])

    key = lo * (len(mesh.vertices) + 1) + hi
    order = np.argsort(key, kind="stable")
    sorted_key = key[order]

    change = np.ones(nl, dtype=bool)
    change[1:] = sorted_key[1:] != sorted_key[:-1]
    group_start = np.flatnonzero(change)
    group_size = np.diff(np.append(group_start, nl))
    # Only manifold edges (exactly two faces) can join two shells.
    pair_start = group_start[group_size == 2]
    i0, i1 = order[pair_start], order[pair_start + 1]

    same = (
        (np.abs(uv_lo[i0] - uv_lo[i1]).max(axis=1) < UV_WELD_EPS)
        & (np.abs(uv_hi[i0] - uv_hi[i1]).max(axis=1) < UV_WELD_EPS)
    )
    face_of_loop = np.repeat(np.arange(nf), totals)
    fa, fb = face_of_loop[i0][same], face_of_loop[i1][same]

    parent = list(range(nf))

    def find(x):
        root = x
        while parent[root] != root:
            root = parent[root]
        while parent[x] != root:  # path compression
            parent[x], x = root, parent[x]
        return root

    for a, b in zip(fa.tolist(), fb.tolist()):
        ra, rb = find(a), find(b)
        if ra != rb:
            parent[rb] = ra

    return np.fromiter((find(i) for i in range(nf)), dtype=np.int64, count=nf)


def texel_ratios(mesh):
    """Per-face texel ratio, constant across each UV shell.

    Texel density is a property of a shell, not of a face: one triangle inside
    an island cannot have its own density, and colouring per face just renders
    the triangulation. So the UV and 3D areas are summed per shell and every
    face of that shell reports the shell's ratio.

    Returns None when the mesh has no UV map.
    """
    nf = len(mesh.polygons)
    if mesh.uv_layers.active is None or nf == 0:
        return None

    nl = len(mesh.loops)
    uv = np.empty(nl * 2, dtype=np.float64)
    mesh.uv_layers.active.data.foreach_get("uv", uv)
    uv = uv.reshape(-1, 2)

    starts = np.empty(nf, dtype=np.int64)
    totals = np.empty(nf, dtype=np.int64)
    mesh.polygons.foreach_get("loop_start", starts)
    mesh.polygons.foreach_get("loop_total", totals)

    idx = np.arange(nl)
    nxt = idx + 1
    nxt[starts + totals - 1] = starts  # wrap each face's last loop to its first
    cross = uv[idx, 0] * uv[nxt, 1] - uv[nxt, 0] * uv[idx, 1]
    uv_area = np.abs(np.add.reduceat(cross, starts) * 0.5)

    area3d = np.empty(nf, dtype=np.float64)
    mesh.polygons.foreach_get("area", area3d)

    shell = _uv_shell_of_face(mesh, uv, starts, totals, nl, nf)
    shell_uv = np.bincount(shell, weights=uv_area, minlength=nf)
    shell_3d = np.bincount(shell, weights=area3d, minlength=nf)
    ratio = shell_uv / np.maximum(shell_3d, 1e-12)
    return ratio[shell].astype(np.float32)


# ---------------------------------------------------------------------------
# Geometry
# ---------------------------------------------------------------------------

def _tri_data(mesh):
    """(vertex indices per triangle, source polygon per triangle) or None."""
    if hasattr(mesh, "calc_loop_triangles"):
        # 4.x computes these on demand; older builds need the explicit call.
        mesh.calc_loop_triangles()
    tri_count = len(mesh.loop_triangles)
    if tri_count == 0:
        return None
    tris = np.empty(tri_count * 3, dtype=np.int32)
    mesh.loop_triangles.foreach_get("vertices", tris)
    polys = np.empty(tri_count, dtype=np.int32)
    mesh.loop_triangles.foreach_get("polygon_index", polys)
    return tris.reshape(-1, 3), polys


def _coords(mesh):
    n = len(mesh.vertices)
    co = np.empty(n * 3, dtype=np.float32)
    mesh.vertices.foreach_get("co", co)
    return co.reshape(-1, 3)


def _build_entry(obj, depsgraph, shader, mode):
    """Batch the evaluated mesh in local space, carrying this mode's scalar."""
    eval_obj = obj.evaluated_get(depsgraph)
    try:
        mesh = eval_obj.to_mesh()
    except RuntimeError:
        return None
    if mesh is None:
        return None

    try:
        if len(mesh.vertices) == 0:
            return None
        tri = _tri_data(mesh)
        if tri is None:
            return None
        tris, polys = tri
        co = _coords(mesh)

        if mode == "TEXEL":
            # Per-face values have to be flat, so the triangles go in
            # unindexed with each corner carrying its own face's ratio.
            ratios = texel_ratios(mesh)
            has_data = ratios is not None
            parts = ()
            if has_data:
                values = np.repeat(ratios[polys], 3)
                vmin, vmax = robust_range(ratios)
                # One entry per UV shell, since that is what Texel mode
                # colours -- each shell has its own density.
                parts = tuple(float(v) for v in np.unique(ratios))
            else:
                values = np.zeros(tris.size, dtype=np.float32)
                vmin, vmax = 0.0, 1.0
            batch = batch_for_shader(
                shader, 'TRIS',
                {"pos": co[tris.ravel()], "val": values},
            )
            return _Entry(batch, vmin, vmax, has_data, parts,
                          _mean(parts if parts else None, ratios))

        if mode == "COST":
            # How many engine vertices each vertex turns into: 1 where the
            # surface is continuous, more at every seam, sharp edge or
            # material boundary meeting there. Normalised per mesh, like
            # VERTEX, because it answers "where is this mesh expensive".
            values = engine_vertex_split(mesh)[1].astype(np.float32)
            vmin = 1.0
            vmax = float(values.max()) if len(values) else 1.0
            parts = ()
        elif mode == "OBJECT":
            values = shell_sizes(mesh)
            vmin = float(values.min()) if len(values) else 0.0
            vmax = float(values.max()) if len(values) else 1.0
            # Object mode resolves a merged mesh into its connected shells, so
            # the legend has to do the same: one entry per distinct shell, not
            # one per object. A character shows its glasses and buttons here
            # exactly as it does in the viewport.
            parts = tuple(float(v) for v in np.unique(values))
        else:
            values = vertex_density(mesh)
            vmin, vmax = robust_range(values)
            parts = ()

        batch = batch_for_shader(
            shader, 'TRIS',
            {"pos": co, "val": values},
            indices=tris,
        )
        # Object mode averages the shells, not the vertices: the parts are
        # what it colours, so a dense little shell counts once, not once per
        # vertex it happens to contain.
        return _Entry(batch, vmin, vmax, True, parts,
                      _mean(parts if mode == "OBJECT" else None, values))
    finally:
        eval_obj.to_mesh_clear()


def _visible_meshes(context):
    space = context.space_data
    for obj in getattr(context, "visible_objects", ()):
        if obj.type != 'MESH':
            continue
        # Nothing solid was rasterized for these, so a tint would read as a
        # filled silhouette floating over whatever is behind them.
        if obj.display_type in {'WIRE', 'BOUNDS'}:
            continue
        # visible_get() with the space also honours local view and per-viewport
        # collection visibility, which context.visible_objects alone does not.
        if obj.visible_get(viewport=space):
            yield obj


def _collect(context, shader, mode):
    depsgraph = context.evaluated_depsgraph_get()
    entries = []
    for obj in _visible_meshes(context):
        entry = _cache.get(obj.session_uid)
        if entry is None:
            entry = _build_entry(obj, depsgraph, shader, mode)
            if entry is None:
                continue
            _cache[obj.session_uid] = entry
        entries.append((obj, entry))
    return entries


def invalidate():
    """Drop every cached batch -- the baked-in scalar depends on the mode."""
    _cache.clear()


# ---------------------------------------------------------------------------
# Draw callbacks
# ---------------------------------------------------------------------------

def _active_settings(context):
    """Settings, or None when the overlay should stay out of the way."""
    space = context.space_data
    if space is None or space.type != 'VIEW_3D':
        return None
    if not space.overlay.show_overlays:
        return None
    # Without a solid depth pass to sit on, the tint would paint flat
    # silhouettes over everything behind it.
    if space.shading.type == 'WIREFRAME' or space.shading.show_xray:
        return None
    settings = getattr(context.scene, "meshan_settings", None)
    if settings is None or not settings.heatmap_enable:
        return None
    return settings


def draw_surfaces():
    global _last_range, _last_mode, _last_ticks, _last_avg

    context = bpy.context
    settings = _active_settings(context)
    if settings is None:
        return
    rv3d = context.region_data
    if rv3d is None:
        return

    mode = settings.heatmap_mode
    shader = _get_shader()
    entries = _collect(context, shader, mode)
    if not entries:
        return

    # OBJECT and TEXEL compare assets against each other, so their range spans
    # the scene. VERTEX asks "where is THIS mesh dense", so it stays per-mesh.
    scene_range = None
    if mode == "OBJECT" and not settings.heatmap_auto_range:
        scene_range = (
            float(settings.heatmap_range_min),
            float(settings.heatmap_range_max),
        )
    elif mode in {"OBJECT", "TEXEL"}:
        useful = [e for _o, e in entries if e.has_data]
        if useful:
            scene_range = (
                min(e.vmin for e in useful),
                max(e.vmax for e in useful),
            )
    if scene_range:
        _last_range = scene_range
    else:
        # VERTEX normalises per mesh, so a scene-wide legend would be a lie.
        # Quote the active object instead -- that is the one being read.
        active = context.active_object
        entry = next(
            (e for o, e in entries if o == active),
            entries[0][1],
        )
        _last_range = (entry.vmin, entry.vmax)
    _last_mode = mode

    # A tick per *part* -- connected shell in Object mode, UV shell in Texel --
    # matching what the viewport actually colours, so a merged object shows up
    # as the several pieces it really is. Vertex mode normalises per mesh, so
    # a shared axis would be meaningless there.
    if mode in {"OBJECT", "TEXEL"}:
        _last_ticks = [
            (value, o.name)
            for o, e in entries if e.has_data
            for value in e.parts if value > 0.0
        ]
        # The average belongs to the selected object, not to the scene: with
        # something picked, "where does this asset sit" is the question, and
        # a scene-wide mean answers a different one. Falls back to the whole
        # set only when nothing usable is selected.
        active_entry = next(
            (e for o, e in entries
             if o == context.active_object and e.has_data),
            None,
        )
        if active_entry is not None and active_entry.mean is not None:
            _last_avg = active_entry.mean
        else:
            means = [e.mean for _o, e in entries
                     if e.has_data and e.mean is not None]
            _last_avg = sum(means) / len(means) if means else None
    else:
        # VERTEX and COST normalise per mesh, so there is no shared axis for
        # an average to sit on -- a mark on this ramp would not mean anything.
        _last_ticks, _last_avg = [], None

    log_scale = 1 if mode == "OBJECT" else 0

    gpu.state.blend_set('ALPHA')
    gpu.state.depth_test_set(DEPTH_TEST)
    gpu.state.depth_mask_set(False)

    shader.bind()
    shader.uniform_float("ViewMatrix", rv3d.view_matrix)
    shader.uniform_float("ProjectionMatrix", rv3d.window_matrix)
    shader.uniform_int("log_scale", log_scale)
    shader.uniform_int("is_perspective", 1 if rv3d.is_perspective else 0)

    for obj, entry in entries:
        lo, hi = scene_range if scene_range else (entry.vmin, entry.vmax)
        shader.uniform_float("ModelMatrix", obj.matrix_world)
        shader.uniform_float("depth_offset", DEPTH_OFFSET)
        shader.uniform_float("lo", lo)
        shader.uniform_float("hi", hi)
        shader.uniform_int("no_data", 0 if entry.has_data else 1)
        entry.batch.draw(shader)

    gpu.state.depth_mask_set(True)
    gpu.state.depth_test_set('NONE')
    gpu.state.blend_set('NONE')


def format_length(metres):
    """A length in whichever metric unit keeps it readable.

    Each end of the ramp picks its own unit. Forcing both onto one unit reads
    tidier but throws away the small end -- a range of 50cm down to 1mm
    becomes "50.0" to "0.1", which is a single significant digit on exactly
    the value an artist is looking at.
    """
    if metres >= 1.0:
        return f"{metres:,.2f}m"
    if metres >= 0.01:
        return f"{metres * 100:,.1f}cm"
    return f"{metres * 1000:,.2f}mm"


def _format_density(px_per_cm):
    """px/cm to two decimals.

    Texel density is compared against a target, not read off in isolation:
    10.24 against 10.00 is the kind of drift a single decimal rounds away
    entirely, and the two ends of the legend can otherwise print the same
    number on a range that genuinely varies.
    """
    return f"{px_per_cm:,.2f}"


def texel_px_per_cm(ratio, texture_size):
    """UV-area-to-3D-area ratio as a px/cm texel density.

    sqrt(ratio) is UV length per metre of surface; times the map size that is
    pixels per metre, and a hundredth of that is the px/cm artists budget in.
    """
    return math.sqrt(max(ratio, 0.0)) * texture_size / 100.0


def _mean(parts, values):
    """Average of `parts` when the mode resolves into them, else of `values`."""
    if parts:
        return float(sum(parts) / len(parts))
    if values is None or len(values) == 0:
        return None
    return float(np.mean(values))


def _legend_labels(settings):
    """(title, low, high) for the ramp, in the units the value actually has."""
    lo, hi = _last_range
    if _last_mode == "OBJECT":
        # The title carries the unit, so the numbers stay bare.
        return "Vertex Count", f"{int(lo):,}", f"{int(hi):,}"

    if _last_mode == "COST":
        # How many engine vertices each one becomes: 1 is free, more is a
        # seam or a sharp edge meeting there.
        return "GPU Vertices", f"{int(lo)}", f"{int(hi)}"

    if _last_mode == "TEXEL":
        size = settings.heatmap_texel_size
        return (
            f"Texel Density @ {size}px",
            _format_density(texel_px_per_cm(lo, size)),
            f"{_format_density(texel_px_per_cm(hi, size))} px/cm",
        )

    # VERTEX carries density (1 / mean incident edge length). Quoting the
    # length itself is the readable form -- the cold end is the least dense,
    # so it is the LONGEST edges.
    longest = 1.0 / lo if lo > 0 else 0.0
    shortest = 1.0 / hi if hi > 0 else 0.0
    return "Edge Length", format_length(longest), format_length(shortest)


def _format_value(value, settings):
    """One value in the same units the legend's end labels are quoted in."""
    if _last_mode == "OBJECT":
        return f"{int(round(value)):,}"
    if _last_mode == "COST":
        return f"{value:.1f}"
    if _last_mode == "TEXEL":
        return _format_density(
            texel_px_per_cm(value, settings.heatmap_texel_size))
    # VERTEX carries density, so quote the edge length it stands for.
    return format_length(1.0 / value if value > 0 else 0.0)


def _normalised(value):
    """Where `value` sits on the ramp, matching what the shader computed."""
    lo, hi = _last_range
    if _last_mode == "OBJECT":            # log, as the shader does
        value = math.log2(max(value, 1.0))
        lo, hi = math.log2(max(lo, 1.0)), math.log2(max(hi, 1.0))
    if hi <= lo:
        return 0.5
    return min(max((value - lo) / (hi - lo), 0.0), 1.0)


def _fill(coords, indices, color):
    shader = gpu.shader.from_builtin('UNIFORM_COLOR')
    batch = batch_for_shader(shader, 'TRIS', {"pos": coords},
                             indices=indices)
    shader.bind()
    shader.uniform_float("color", color)
    batch.draw(shader)


def _quad(x0, y0, x1, y1):
    return [(x0, y0), (x1, y0), (x1, y1), (x0, y1)], [(0, 1, 2), (0, 2, 3)]


def _disc(cx, cy, radius, segments=16):
    coords = [(cx, cy)]
    for i in range(segments + 1):
        a = math.tau * i / segments
        coords.append((cx + math.cos(a) * radius, cy + math.sin(a) * radius))
    indices = [(0, i, i + 1) for i in range(1, segments + 1)]
    return coords, indices


def draw_legend():
    context = bpy.context
    settings = _active_settings(context)
    if settings is None or not settings.heatmap_show_legend:
        return

    region = context.region
    scale = context.preferences.system.ui_scale
    width, height = 180 * scale, 10 * scale
    margin = 16 * scale
    x = region.width - width - margin
    y = margin + 14 * scale  # above the labels, which sit under the bar

    steps = 32
    coords, colors, indices = [], [], []
    for i in range(steps + 1):
        t = i / steps
        px = x + width * t
        coords += [(px, y), (px, y + height)]
        colors += [(*ramp_color(t), 1.0)] * 2
        if i < steps:
            base = i * 2
            indices += [
                (base, base + 1, base + 2),
                (base + 1, base + 3, base + 2),
            ]

    shader = gpu.shader.from_builtin('SMOOTH_COLOR')
    batch = batch_for_shader(
        shader, 'TRIS', {"pos": coords, "color": colors}, indices=indices)
    gpu.state.blend_set('ALPHA')
    batch.draw(shader)

    # One tick per object, so a flat-looking ramp still shows whether the
    # scene is clustered at one end or spread across it. The active object's
    # tick is drawn full height so you can find it among the others.
    active = context.active_object
    active_name = active.name if active else None
    tick_w = max(1.0, round(scale))
    for value, name in _last_ticks:
        tx = x + width * _normalised(value)
        is_active = name == active_name
        pad = 0.0 if is_active else height * 0.25
        c, i = _quad(tx - tick_w * 0.5, y + pad,
                     tx + tick_w * 0.5, y + height - pad)
        _fill(c, i, (1.0, 1.0, 1.0, 1.0 if is_active else 0.65))

    # The selected object's average, as a dot riding just above the ramp --
    # close enough to read against it, clear enough not to look stuck to it.
    avg_y = y + height + 5.5 * scale
    if _last_avg is not None:
        ax = x + width * _normalised(_last_avg)
        c, i = _disc(ax, avg_y, 3.5 * scale)
        _fill(c, i, (0.0, 0.0, 0.0, 0.55))
        c, i = _disc(ax, avg_y, 2.5 * scale)
        _fill(c, i, (1.0, 1.0, 1.0, 0.95))

    gpu.state.blend_set('NONE')

    title, low_label, high_label = _legend_labels(settings)
    font_id = 0
    blf.size(font_id, 11 * scale)
    blf.color(font_id, 1.0, 1.0, 1.0, 0.9)
    blf.position(font_id, x, margin, 0)
    blf.draw(font_id, low_label)
    blf.position(
        font_id, x + width - blf.dimensions(font_id, high_label)[0], margin, 0)
    blf.draw(font_id, high_label)

    # The dot alone says where the average sits but not what it is, so the
    # value rides beside it -- offset right, and flipped to the left when
    # that would push it off the end of the ramp.
    if _last_avg is not None:
        text = _format_value(_last_avg, settings)
        blf.size(font_id, 10 * scale)
        blf.color(font_id, 1.0, 1.0, 1.0, 0.75)
        tw = blf.dimensions(font_id, text)[0]
        tx = ax + 6 * scale
        if tx + tw > x + width:
            tx = ax - 6 * scale - tw
        blf.position(font_id, tx, avg_y - 3.5 * scale, 0)
        blf.draw(font_id, text)
        blf.size(font_id, 11 * scale)

    blf.color(font_id, 1.0, 1.0, 1.0, 0.55)
    blf.position(font_id, x, y + height + 13 * scale, 0)
    blf.draw(font_id, title)


# ---------------------------------------------------------------------------
# Cache invalidation
# ---------------------------------------------------------------------------

@persistent
def _on_depsgraph_update(scene, depsgraph):
    """Rebuild only what changed shape. Transforms ride the model matrix."""
    prune = False
    for update in depsgraph.updates:
        id_block = update.id
        if isinstance(id_block, bpy.types.Object):
            if update.is_updated_geometry:
                # `.original`: a depsgraph update carries the evaluated copy,
                # whose session_uid is 0 rather than the object's.
                _cache.pop(id_block.original.session_uid, None)
        elif isinstance(id_block, (bpy.types.Scene, bpy.types.Collection)):
            prune = True
    if prune:
        live = {o.session_uid for o in bpy.data.objects}
        for key in [k for k in _cache if k not in live]:
            del _cache[key]


@persistent
def _on_load(_file):
    _cache.clear()


# ---------------------------------------------------------------------------
# Registration
# ---------------------------------------------------------------------------

def register():
    global _surface_handle, _legend_handle

    _surface_handle = bpy.types.SpaceView3D.draw_handler_add(
        draw_surfaces, (), 'WINDOW', 'POST_VIEW')
    _legend_handle = bpy.types.SpaceView3D.draw_handler_add(
        draw_legend, (), 'WINDOW', 'POST_PIXEL')

    bpy.app.handlers.depsgraph_update_post.append(_on_depsgraph_update)
    bpy.app.handlers.load_post.append(_on_load)


def unregister():
    global _surface_handle, _legend_handle, _shader

    if _on_load in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.remove(_on_load)
    if _on_depsgraph_update in bpy.app.handlers.depsgraph_update_post:
        bpy.app.handlers.depsgraph_update_post.remove(_on_depsgraph_update)

    if _legend_handle is not None:
        bpy.types.SpaceView3D.draw_handler_remove(_legend_handle, 'WINDOW')
        _legend_handle = None
    if _surface_handle is not None:
        bpy.types.SpaceView3D.draw_handler_remove(_surface_handle, 'WINDOW')
        _surface_handle = None

    _cache.clear()
    _shader = None
