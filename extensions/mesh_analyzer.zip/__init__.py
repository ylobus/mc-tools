"""Mesh Analyzer -- mesh analysis for game art, for the MightyCanvas pipeline.

Two modules, asking two questions about the same mesh:

  * `validation`    -- does this asset pass? Checks, results, the sidebar
                       panels under Item, and shareable presets.
  * `visualization` -- where does it spend its budget? The density/texel/cost
                       heatmap and the viewport readout, both in Overlays.

They overlap where the readout draws validation's results in the viewport,
so `visualization` imports from `validation` and never the other way round.
`properties` sits above both: one settings block on `Scene.meshan_settings`,
because a check budget and the heatmap that shows it belong together.

Registration and wiring only; the work lives in the modules.
"""

import bpy

from . import properties
from .validation import operators, presets, results, ui
from .visualization import heatmap, viewport_text

classes = (
    properties.MeshAnalyzerSettings,
    *operators.classes,
    *presets.classes,
)


def register():
    for cls in classes:
        bpy.utils.register_class(cls)

    bpy.types.Scene.meshan_settings = bpy.props.PointerProperty(
        type=properties.MeshAnalyzerSettings
    )

    ui.register()
    heatmap.register()
    viewport_text.register()
    results.register()


def unregister():
    results.unregister()
    viewport_text.unregister()
    heatmap.unregister()
    ui.unregister()

    del bpy.types.Scene.meshan_settings

    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)

