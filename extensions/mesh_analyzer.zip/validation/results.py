"""The check runner and the session result store.

Results are keyed by ``ID.session_uid`` -- stable across renames and unique
within a session -- not by object name: name keying orphaned results the
moment a user renamed an object, and mixed objects up across appended files
with clashing names.
"""

import bmesh
import bpy
from bpy.app.handlers import persistent

from .checks import MESH_LEVEL_IDS, OBJECT_LEVEL_IDS, SECTIONS

results = {}      # session_uid -> {check_id: result dict}
stats = {}        # session_uid -> {"verts": int, "faces": int, "tris": int}
# session_uid -> True when the checked geometry still lines up with the
# editable mesh, so the indices the checks recorded can be selected.
selectable = {}


def uid(obj):
    return obj.session_uid


def prune_stale():
    """Drop results for objects that no longer exist."""
    live = {o.session_uid for o in bpy.data.objects}
    for store in (results, stats, selectable):
        for key in [k for k in store if k not in live]:
            del store[key]


def _visible_modifiers(obj):
    return [m for m in obj.modifiers if m.show_viewport]


def is_selectable(obj):
    """Whether offenders found on this object can be selected.

    Checks always run on the evaluated mesh -- what the modifier stack
    actually produces is what ships -- but that mesh is not always the one
    you can edit. Deforming modifiers (Armature, Lattice, Shape keys, Cast,
    Simple Deform...) move vertices and leave the topology alone, so index
    *n* means the same vertex in both and selection works. Generating ones
    (Subdivision, Mirror, Array, Solidify, Boolean, Decimate, Remesh...)
    build new geometry, and an index into their output points at something
    that does not exist in the editable mesh.

    Element counts are the test: equal counts mean no generator ran, since
    every generator changes at least one of them. It is a heuristic, not a
    proof of index correspondence, but Blender's deform modifiers preserve
    order, so in practice it holds -- and it fails safe, because the only
    consequence of a wrong answer is a greyed-out button.
    """
    if obj is None or obj.type != "MESH":
        return True
    cached = selectable.get(uid(obj))
    if cached is not None:
        return cached
    return not _visible_modifiers(obj)


def settings(context):
    return context.scene.meshan_settings


def is_enabled(prefs, check_id):
    return getattr(prefs, f"enable_{check_id}", True)


def _check_mesh(obj):
    """(bmesh, mesh, release, matches) for the geometry to validate.

    Always the *evaluated* mesh: modifiers are part of the asset, and a mesh
    that is clean before a Mirror and full of n-gons after it is not clean.
    Checking the base mesh would pass assets that fail in engine.

    The evaluated mesh is handed back alive and stays that way until
    `release()`, so the checks that read mesh data rather than topology --
    UV layers, material slots, the vertex budget -- see the same modifier
    output the bmesh came from. Evaluating once for all of them is also a
    good deal cheaper than each one evaluating its own copy.
    """
    depsgraph = bpy.context.evaluated_depsgraph_get()
    evaluated = obj.evaluated_get(depsgraph)
    try:
        mesh = evaluated.to_mesh()
    except RuntimeError:
        mesh = None

    if mesh is None:
        # No evaluated mesh to be had -- fall back to what is editable.
        if obj.mode == "EDIT":
            bm = bmesh.from_edit_mesh(obj.data)
            return bm, obj.data, (lambda: None), True
        bm = bmesh.new()
        bm.from_mesh(obj.data)
        return bm, obj.data, bm.free, True

    counts = (len(mesh.vertices), len(mesh.edges), len(mesh.polygons))
    bm = bmesh.new()
    bm.from_mesh(mesh)

    def release():
        bm.free()
        evaluated.to_mesh_clear()

    return bm, mesh, release, counts == _editable_counts(obj)


def _editable_counts(obj):
    """Element counts of the geometry a select actually lands in.

    In Edit Mode that is the live bmesh, not `obj.data` -- the datablock
    still holds the pre-edit topology, so comparing against it would read an
    in-progress edit as a generating modifier.
    """
    if obj.mode == "EDIT":
        bm = bmesh.from_edit_mesh(obj.data)
        return len(bm.verts), len(bm.edges), len(bm.faces)
    mesh = obj.data
    return len(mesh.vertices), len(mesh.edges), len(mesh.polygons)


def run_checks_on_object(obj, prefs):
    bm, mesh, release, matches = _check_mesh(obj)
    try:
        bm.verts.ensure_lookup_table()
        bm.edges.ensure_lookup_table()
        bm.faces.ensure_lookup_table()

        selectable[uid(obj)] = bool(matches)

        stats[uid(obj)] = {
            "verts": len(bm.verts),
            "faces": len(bm.faces),
            "tris": sum(len(f.verts) - 2 for f in bm.faces),
        }

        found = {}
        for _skey, _title, _icon, checks in SECTIONS:
            for check_id, _label, fn in checks:
                if not is_enabled(prefs, check_id):
                    continue
                try:
                    if check_id in MESH_LEVEL_IDS:
                        # Reads mesh data, so it gets the evaluated mesh --
                        # a modifier can add a UV layer or a material.
                        found[check_id] = fn(obj, mesh, prefs)
                    elif check_id in OBJECT_LEVEL_IDS:
                        # Object transforms; no modifier can change them.
                        found[check_id] = fn(obj)
                    else:
                        found[check_id] = fn(bm, obj)
                except Exception as exc:
                    found[check_id] = {"count": -1, "error": str(exc)}
    finally:
        release()

    results[uid(obj)] = found
    return found


def failed_count(found):
    """Failures: issues that are not informational, plus checks that errored."""
    return sum(
        1 for r in found.values()
        if (r["count"] > 0 and not r.get("info")) or r["count"] == -1
    )


def tally(found, prefs):
    """(passed, total) over the checks that can actually score.

    Informational checks never score. Neither do skipped ones -- a mesh with
    no UV map must not collect credit for passing the five UV checks that
    never ran.
    """
    scored = [
        r for cid, r in found.items()
        if not r.get("info") and not r.get("skipped") and is_enabled(prefs, cid)
    ]
    return sum(1 for r in scored if r["count"] == 0), len(scored)


def score(found, prefs):
    """Fraction of scoring checks that passed, for the health bar."""
    passed, total = tally(found, prefs)
    return (passed / total) if total else 0.0


@persistent
def _on_load(_file):
    """A loaded file has its own objects; carrying results over would show
    another scene's verdicts against them."""
    results.clear()
    stats.clear()
    selectable.clear()


def register():
    bpy.app.handlers.load_post.append(_on_load)


def unregister():
    if _on_load in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.remove(_on_load)
    results.clear()
    stats.clear()
    selectable.clear()
