"""Saving and loading a check configuration as a file.

A preset is which checks are on and what the budgets are -- the part of the
setup that belongs to a project rather than to a person. Plain JSON, so it
lives in the repo next to the assets, diffs in review, and a team shares one
file instead of each artist remembering the rules.

Deliberately not Blender's preset system: that writes Python into the user's
config directory, which is per-machine and not something you can put under
version control.
"""

import json
import os

import bpy

from .checks import SECTIONS

EXTENSION = ".json"
DEFAULT_NAME = "validation"
FORMAT_VERSION = 1

# Budget fields are enumerated rather than discovered, so a preset never
# carries unrelated settings (viewport colours, heatmap mode) between users.
BUDGET_KEYS = (
    "budget_verts",
    "budget_uv_maps_min", "budget_uv_maps_max",
    "budget_materials_min", "budget_materials_max",
)


def check_ids():
    return [c[0] for _k, _t, _i, checks in SECTIONS for c in checks]


def to_dict(prefs):
    return {
        "format": FORMAT_VERSION,
        "checks": {cid: bool(getattr(prefs, f"enable_{cid}"))
                   for cid in check_ids()},
        "budgets": {key: int(getattr(prefs, key)) for key in BUDGET_KEYS},
    }


def from_dict(prefs, data):
    """Apply a preset, returning (applied, ignored) counts.

    Unknown keys are ignored rather than raising: a preset written by a newer
    build should still configure everything this one understands.
    """
    applied = ignored = 0
    for cid, value in (data.get("checks") or {}).items():
        if hasattr(prefs, f"enable_{cid}"):
            setattr(prefs, f"enable_{cid}", bool(value))
            applied += 1
        else:
            ignored += 1
    for key, value in (data.get("budgets") or {}).items():
        if key in BUDGET_KEYS and hasattr(prefs, key):
            setattr(prefs, key, int(value))
            applied += 1
        else:
            ignored += 1
    return applied, ignored


class MESHAN_OT_preset_save(bpy.types.Operator):
    """Save the current checks and budgets to a shareable preset file"""
    bl_idname = "meshan.preset_save"
    bl_label = "Save Preset"

    filepath: bpy.props.StringProperty(subtype="FILE_PATH")
    filter_glob: bpy.props.StringProperty(default="*.json", options={"HIDDEN"})

    def invoke(self, context, event):
        if not self.filepath:
            self.filepath = "//" + DEFAULT_NAME + EXTENSION
        context.window_manager.fileselect_add(self)
        return {"RUNNING_MODAL"}

    def execute(self, context):
        from .results import settings
        path = bpy.path.abspath(self.filepath)
        if not path.lower().endswith(".json"):
            path += EXTENSION
        try:
            with open(path, "w", encoding="utf-8") as handle:
                json.dump(to_dict(settings(context)), handle, indent=1)
                handle.write("\n")
        except OSError as exc:
            self.report({"ERROR"}, f"Could not write preset: {exc}")
            return {"CANCELLED"}
        self.report({"INFO"}, f"Preset saved: {os.path.basename(path)}")
        return {"FINISHED"}


class MESHAN_OT_preset_load(bpy.types.Operator):
    """Load checks and budgets from a preset file"""
    bl_idname = "meshan.preset_load"
    bl_label = "Load Preset"
    bl_options = {"REGISTER", "UNDO"}

    filepath: bpy.props.StringProperty(subtype="FILE_PATH")
    filter_glob: bpy.props.StringProperty(default="*.json", options={"HIDDEN"})

    def invoke(self, context, event):
        context.window_manager.fileselect_add(self)
        return {"RUNNING_MODAL"}

    def execute(self, context):
        from .results import settings
        path = bpy.path.abspath(self.filepath)
        try:
            with open(path, "r", encoding="utf-8") as handle:
                data = json.load(handle)
        except (OSError, ValueError) as exc:
            self.report({"ERROR"}, f"Could not read preset: {exc}")
            return {"CANCELLED"}
        if not isinstance(data, dict):
            self.report({"ERROR"}, "Not a validation preset")
            return {"CANCELLED"}

        applied, ignored = from_dict(settings(context), data)
        note = f"Preset loaded: {applied} setting(s)"
        if ignored:
            note += f", {ignored} unknown ignored"
        self.report({"INFO"}, note)
        return {"FINISHED"}


classes = (MESHAN_OT_preset_save, MESHAN_OT_preset_load)
