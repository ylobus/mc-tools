"""Operators: running the checks and jumping to what they found.

No auto-fixes. The tool reports; deciding what to do about an n-gon or a
loose vertex is the artist's call, and a button that rewrites their topology
on their behalf is the wrong kind of help.
"""

import bmesh
import bpy

from . import results
from ..visualization import viewport_text


def _clear_selection(bm):
    for v in bm.verts:
        v.select = False
    for e in bm.edges:
        e.select = False
    for f in bm.faces:
        f.select = False


def _targets(context):
    """Every mesh the Validate button should cover, active object first.

    Selecting a collection in the Outliner does not select its objects, and
    the 3D-view panel cannot see the Outliner's selection at all. What it can
    see is `selected_ids`, which the Outliner fills with whatever is
    highlighted there -- collections included -- so picking a collection and
    hitting Validate checks everything inside it, nested collections and all.
    Otherwise it falls back to the selected objects, then the active one.
    """
    found = []
    seen = set()

    def add(obj):
        if obj is not None and obj.type == "MESH" \
                and obj.session_uid not in seen:
            seen.add(obj.session_uid)
            found.append(obj)

    for datablock in getattr(context, "selected_ids", ()) or ():
        if isinstance(datablock, bpy.types.Collection):
            for obj in datablock.all_objects:
                add(obj)

    if not found:
        for obj in context.selected_objects:
            add(obj)
    add(context.active_object)
    return found


class MESHAN_OT_run(bpy.types.Operator):
    """Run all enabled checks.

    Covers every selected mesh, or every mesh in a collection selected in the
    Outliner; falls back to the active object
    """
    bl_idname = "meshan.run"
    bl_label = "Validate"
    bl_options = {"REGISTER"}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj is not None and obj.type == "MESH"

    def execute(self, context):
        results.prune_stale()
        prefs = results.settings(context)
        targets = _targets(context)
        if not targets:
            self.report({"WARNING"}, "No mesh to validate")
            return {"CANCELLED"}

        failing = 0
        for obj in targets:
            found = results.run_checks_on_object(obj, prefs)
            if results.failed_count(found):
                failing += 1
        viewport_text.tag_redraw()

        # INFO, not WARNING: the check pass itself succeeded. A warning banner
        # here reads as "the tool went wrong", which makes the result look
        # untrustworthy when it is simply reporting what it found.
        if len(targets) == 1:
            obj = targets[0]
            failed = results.failed_count(results.results[results.uid(obj)])
            note = (f"{obj.name}: all checks passed" if failed == 0
                    else f"{obj.name}: {failed} check(s) failed")
        else:
            note = (f"{len(targets)} meshes checked, "
                    f"{failing} with failures")
        self.report({"INFO"}, note)
        return {"FINISHED"}


class MESHAN_OT_select(bpy.types.Operator):
    """Select the offending geometry for this check"""
    bl_idname = "meshan.select"
    bl_label = "Select Offenders"
    bl_options = {"REGISTER", "UNDO"}

    check_id: bpy.props.StringProperty()

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return (
            obj is not None
            and obj.type == "MESH"
            and results.uid(obj) in results.results
        )

    def execute(self, context):
        obj = context.active_object
        result = results.results.get(results.uid(obj), {}).get(self.check_id)
        if not result:
            self.report({"WARNING"}, "Run checks first")
            return {"CANCELLED"}

        # The indices came from the modifier output. When a modifier
        # generates geometry they do not point at anything editable, and
        # selecting by them would highlight unrelated vertices.
        if not results.is_selectable(obj):
            self.report(
                {"WARNING"},
                "Checked with modifiers applied - the offending geometry "
                "does not exist in the editable mesh",
            )
            return {"CANCELLED"}

        if obj.mode != "EDIT":
            bpy.ops.object.mode_set(mode="EDIT")

        bm = bmesh.from_edit_mesh(obj.data)
        bm.verts.ensure_lookup_table()
        bm.edges.ensure_lookup_table()
        bm.faces.ensure_lookup_table()
        _clear_selection(bm)

        modes = set()
        for idx in result.get("verts", []):
            if idx < len(bm.verts):
                bm.verts[idx].select = True
                modes.add("VERT")
        for idx in result.get("edges", []):
            if idx < len(bm.edges):
                bm.edges[idx].select = True
                modes.add("EDGE")
        for idx in result.get("faces", []):
            if idx < len(bm.faces):
                bm.faces[idx].select = True
                modes.add("FACE")

        bm.select_flush(True)
        bmesh.update_edit_mesh(obj.data)

        if "FACE" in modes:
            context.tool_settings.mesh_select_mode = (False, False, True)
        elif "EDGE" in modes:
            context.tool_settings.mesh_select_mode = (False, True, False)
        elif "VERT" in modes:
            context.tool_settings.mesh_select_mode = (True, False, False)

        self.report({"INFO"}, f"Selected {result.get('count', 0)} element(s)")
        return {"FINISHED"}


classes = (
    MESHAN_OT_run,
    MESHAN_OT_select,
)
