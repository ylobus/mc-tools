"""The Item-tab panels and the Overlays-popover entries.

Everything lives under the sidebar's **Item** tab now: a Validate button with
a health bar, then one collapsible sub-panel per check category. Each row
carries its own enable checkbox, so there is no separate settings list to
keep in sync with the results -- the toggle and the verdict sit on one line.

The viewport readout and the density heatmap are configured from the
Overlays popover only; they are viewport display, not panel state.
"""

import bpy

from .checks import NON_SELECTABLE_IDS, SECTIONS
from .results import (
    failed_count, is_enabled, is_selectable, results, score, settings, tally,
    uid,
)
from ..visualization.viewport_text import (
    COLOR_FAIL, COLOR_INFO, COLOR_PASS, section_color, section_tally,
)


def _mc_highlight_container(layout, context):
    """MC Highlight (see MC Tools): when on, draw into a red-alert bordered
    box; otherwise a plain horizontal row. Loose-coupled, no imports."""
    if getattr(context.window_manager, "mc_highlight", False):
        box = layout.box()
        box.alert = True
        row = box.row(align=True)
        row.alert = True
        return row
    return layout.row(align=True)


# Ladder from "ship it" to "start over". A+ is reserved for a clean sweep --
# a grade you can only get by fixing everything is worth more than one that
# rounds up.
GRADES = (
    (1.00, "A+"), (0.95, "A"), (0.90, "A-"),
    (0.85, "B+"), (0.80, "B"), (0.75, "B-"),
    (0.70, "C+"), (0.65, "C"), (0.60, "C-"),
    (0.50, "D"), (0.00, "F"),
)


def grade(ratio):
    """Letter for a pass ratio."""
    for threshold, letter in GRADES:
        if ratio >= threshold:
            return letter
    return "F"


def health_score(found, prefs):
    """0-100. Every enabled check passing is 100; informational and
    inapplicable checks are excluded, so they cannot pad the number."""
    return int(round(score(found, prefs) * 100))


# Below this many UI units the sidebar is too narrow for the full row: the
# tally starts overprinting category titles and the right-hand columns leave
# nothing for the check name. A default sidebar is about 14 units, so this
# only trips once it has actually been dragged in.
NARROW_UNITS = 11.5


def region_units(context):
    """Sidebar width in UI units -- the currency layout widths are set in.

    One unit is 20px before scaling. Blender scales the sidebar's stored
    width along with `ui_scale`, so this is a real measure of how much room
    the panel has, not a proxy for it.
    """
    region = context.region
    if region is None:
        return 999.0
    scale = context.preferences.system.ui_scale or 1.0
    return region.width / (20.0 * scale)


def draw_health_bar(layout, found, prefs):
    """The grade, then one stretched colour block per category.

    Six blocks spanning the panel, not a row of small icons: a colour swatch
    is the one panel widget that expands to fill the space it is given, so
    six of them divide the width evenly. Icons are a fixed size, which is why
    the earlier attempts either left a stub of a bar or faked the width by
    repeating each colour.

    Not `UILayout.progress()` either: that draws in the theme's progress
    colour and ignores `alert`, so it reads the same at 100 and at 12.
    """
    col = layout.column(align=True)

    if found:
        # Score first, bar last: the panel then ends on the bar, which is what
        # keeps the Checks sub-panel from being pushed down.
        passed, total = tally(found, prefs)
        label = col.row()
        label.alignment = "CENTER"
        label.scale_y = 0.75
        # Two sub-rows, each given its own width: siblings in a row otherwise
        # split the space evenly, which truncates the tally to "14 / 1...".
        # Tier first: it is the headline, and the tally is the detail behind
        # it. Always drawn in the alert colour -- it is a rank, not a
        # verdict, and a letter that changed colour with the result would
        # only repeat what the bar already says.
        tier = label.row()
        tier.ui_units_x = 2.2
        tier.alignment = "RIGHT"
        tier.alert = True
        tier.label(text=grade(score(found, prefs)))
        count = label.row()
        count.ui_units_x = 3.4
        count.alignment = "LEFT"
        count.label(text=f"    {passed} / {total}")

    bar = col.row(align=True)
    bar.scale_y = 0.45
    for skey, _title, _icon, _checks in SECTIONS:
        bar.prop(prefs, f"bar_{skey}", text="")


class MESHAN_PT_item(bpy.types.Panel):
    """Validation, in the sidebar's Item tab beside the transform fields."""

    bl_label = "Validation"
    bl_idname = "MESHAN_PT_item"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Item"

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj is not None and obj.type == "MESH"

    def draw(self, context):
        layout = self.layout
        obj = context.active_object
        prefs = settings(context)
        found = results.get(uid(obj))

        run = _mc_highlight_container(layout, context)
        run.scale_y = 1.4
        run.operator("meshan.run", text="Validate", icon="PLAY")

        draw_health_bar(layout, found, prefs)


class MESHAN_PT_checks(bpy.types.Panel):
    """One collapse holding every category, so the whole breakdown folds away
    and leaves just Validate and the bar."""

    bl_label = "Checks"
    bl_idname = "MESHAN_PT_checks"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Item"
    bl_parent_id = "MESHAN_PT_item"
    bl_options = {"DEFAULT_CLOSED"}

    def draw(self, context):
        pass          # the category sub-panels are the content


class _SectionPanel(bpy.types.Panel):
    """One collapsible category of checks, nested under Checks.

    Subclasses set `section_key` and `section_icon`; everything else is
    shared. Rows read checkbox | label | verdict | select | fix, so enabling a
    check and reading its result are the same place.
    """

    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Item"
    bl_parent_id = "MESHAN_PT_checks"
    bl_options = {"DEFAULT_CLOSED"}

    section_key = ""
    section_icon = "NONE"

    def draw_header(self, context):
        # Panels have no icon field, so the category icon goes in the header
        # ahead of the label -- the same marks the original add-on used --
        # next to a master switch for the whole category. The icon reddens
        # with the tally when something in the category failed.
        prefs = settings(context)
        obj = context.active_object
        found = results.get(uid(obj)) if obj else None
        row = self.layout.row(align=True)
        row.prop(prefs, f"enable_section_{self.section_key}", text="")
        mark = row.row(align=True)
        if found:
            checks = next(c for k, _t, _i, c in SECTIONS
                          if k == self.section_key)
            mark.alert = section_color(found, prefs, checks) == COLOR_FAIL
        mark.label(text="", icon=self.section_icon)

    def draw_header_preset(self, context):
        """The category's tally, right-aligned in the header.

        Dulled rather than reddened when it is short of a clean sweep: red on
        "2/3" reads as *two* things being wrong, when two is the part that
        went right. The red belongs on the icon, which has no such reading.

        Dropped entirely in a narrow sidebar: a header does not wrap or
        elide, so Blender draws the tally straight over the title and you
        get "B<2/3>dget". No tally reads better than a garbled one -- the
        colour on the icon still carries the category's state.
        """
        if region_units(context) < NARROW_UNITS:
            return
        obj = context.active_object
        found = results.get(uid(obj)) if obj else None
        if not found:
            return
        prefs = settings(context)
        checks = next(c for k, _t, _i, c in SECTIONS if k == self.section_key)
        passing, applicable = section_tally(found, prefs, checks)
        if not applicable:
            return
        row = self.layout.row(align=True)
        row.enabled = passing == applicable
        row.label(text=f"{passing}/{applicable}")

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = False
        obj = context.active_object
        prefs = settings(context)
        found = results.get(uid(obj)) or {}

        checks = next(c for k, _t, _i, c in SECTIONS if k == self.section_key)
        col = layout.column(align=True)
        selectable = is_selectable(obj)
        units = region_units(context)
        for check_id, label, _fn in checks:
            self._row(col, prefs, check_id, label, found.get(check_id),
                      selectable, units)

    # The limit fields for the budget rows, drawn inline on the row itself so
    # the number you measured and the number you allow sit together and the
    # panel costs no extra height.
    LIMITS = {
        "vert_budget": ("budget_verts",),
        "uv_maps": ("budget_uv_maps_min", "budget_uv_maps_max"),
        "materials": ("budget_materials_min", "budget_materials_max"),
    }

    # Widths of the right-hand columns, in UI units. Fixed rather than a
    # fraction of the row: a number field has a minimum usable size, so a
    # proportional split either starves the fields in a narrow sidebar or
    # stretches them absurdly in a wide one. Pinning them and letting the
    # name absorb whatever is left is what actually adapts -- the label
    # grows and shrinks with the panel while the numbers stay readable.
    VALUE_W = 2.6
    # A lone limit gets the width of two: the vertex budget is a five-digit
    # number, and a field sized for a one-digit UV count renders it "10".
    LIMIT_W = 2.6
    LIMIT_W_SOLO = 4.4
    JUMP_W = 1.3

    def _row(self, col, prefs, check_id, label, result, selectable=True,
             units=999.0):
        enabled = is_enabled(prefs, check_id)
        limits = self.LIMITS.get(check_id, ())
        # Reserving the jump slot keeps the numbers in one column instead of
        # stepping left and right as checks pass and fail -- but only while
        # there is width to spare. Narrow, every unit belongs to the name.
        roomy = units >= NARROW_UNITS
        jumpable = check_id not in NON_SELECTABLE_IDS
        # Narrow, the limit fields drop to their own line under the check
        # rather than being squeezed inline, where they shrink to grey boxes
        # too small to show their own digits. Two readable lines beat one
        # unreadable one, and nothing becomes unreachable.
        stacked = bool(limits) and not roomy
        limit_w = self.LIMIT_W_SOLO if len(limits) == 1 else self.LIMIT_W
        wanted = (self.VALUE_W
                  + (0.0 if stacked else limit_w * len(limits))
                  + (self.JUMP_W if jumpable and roomy else 0.0))

        # Never let the fixed columns take more than half the row. Below that
        # the name has nothing left and every check reads "Zer...", which is
        # worse than a slightly cramped number field. Children shrink by the
        # same factor so their proportions survive the squeeze.
        allowed = min(wanted, units * 0.5)
        shrink = allowed / wanted if wanted else 1.0

        # A split, not `ui_units_x` on the right-hand row: inside an ordinary
        # row that only acts as a minimum and the two halves still come out
        # even. Deriving the factor from the measured width gives the same
        # result a fixed column would -- the name keeps every unit the
        # numbers do not need, at whatever width the sidebar happens to be.
        split = col.row(align=True).split(
            factor=max(0.35, 1.0 - allowed / units), align=True)

        # Checkbox and name are one widget, so hovering anywhere on the name
        # raises the check's tooltip -- what it looks for and why it matters.
        # A plain label carries no tooltip at all.
        name = split.row(align=True)
        name.prop(prefs, f"enable_{check_id}", text=label)

        right = split.row(align=True)
        right.alignment = "RIGHT"

        # The measurement first, then the range that judges it: reading
        # "3  [1] [2]" left to right is what the mesh has, then what it was
        # allowed. With one limit the single field simply follows the number.
        value = right.row(align=True)
        value.ui_units_x = self.VALUE_W * shrink
        text, failed = self._verdict(prefs, check_id, enabled, result)
        # A non-zero informational count is dulled rather than reddened: it
        # is a measurement the check reports, not a failure, and red would
        # claim a problem the check is not making. Real failures stay bright
        # -- dulling them would take the force out of the alert colour.
        muted = bool(result) and bool(result.get("info")) \
            and result.get("count", 0) > 0
        value.enabled = enabled and result is not None \
            and not result.get("skipped") and not muted
        value.alert = failed
        value.label(text=text)

        if stacked:
            under = col.row(align=True)
            under.enabled = enabled
            for limit in limits:
                under.prop(prefs, limit, text="")
        else:
            for limit in limits:
                field = right.row(align=True)
                field.ui_units_x = limit_w * shrink
                field.enabled = enabled
                field.prop(prefs, limit, text="")

        if not jumpable:
            return
        has_offenders = (
            enabled and result is not None and not result.get("skipped")
            and result["count"] > 0 and not result.get("info")
        )
        if not has_offenders and not roomy:
            return                        # narrow: no width to hold open
        jump = right.row(align=True)
        jump.ui_units_x = self.JUMP_W * shrink
        if not has_offenders:
            jump.label(text="")           # holds the column open
            return
        # A modifier that generates geometry breaks the link between what was
        # checked and what can be picked, so the button greys out rather than
        # selecting the wrong vertices. The panel says why.
        jump.enabled = selectable
        jump.operator(
            "meshan.select", text="", icon="RESTRICT_SELECT_OFF"
        ).check_id = check_id

    @staticmethod
    def _verdict(prefs, check_id, enabled, result):
        """(text, is_failure) for the result column.

        Deliberately only ever "OK" or a number. Prose verdicts -- "off",
        "error", "non-uniform", "0.310m off" -- each needed their own reading
        and truncated to nonsense in a narrow sidebar. A count says the same
        thing in a form that scans down the column at a glance; the row's
        tooltip carries the explanation.
        """
        if not enabled or result is None or result.get("skipped"):
            # Nothing ran: an unticked box, an unvalidated mesh and a check
            # that could not apply all speak for themselves.
            return "", False
        count = result["count"]
        if count == -1:
            # The one non-number left. A check that threw is a fault in the
            # tool, and silently showing "OK" for it would be a lie.
            return "!", True
        if count == 0:
            # Budgets report their measurement even when they pass; a bare
            # "OK" would hide the number you set the budget to watch.
            return result.get("note") or "OK", False
        # Budgets keep reporting their measurement when they fail too: "3"
        # against a max of 2 is the useful number, not "1 problem".
        return result.get("note") or f"{count:,}", not result.get("info")


def _make_section_panels():
    """One panel class per entry in the check registry, so adding a category
    in checks.py needs no edit here."""
    made = []
    for skey, title, section_icon, _checks in SECTIONS:
        made.append(type(
            f"MESHAN_PT_section_{skey}",
            (_SectionPanel,),
            {
                "bl_label": title,
                "bl_idname": f"MESHAN_PT_section_{skey}",
                "section_key": skey,
                "section_icon": section_icon,
                "__doc__": f"{title} checks.",
            },
        ))
    return tuple(made)


SECTION_PANELS = _make_section_panels()


class MESHAN_PT_presets(bpy.types.Panel):
    """Save and load the check configuration.

    Registered after the category panels so it lands at the bottom of the
    list -- Blender orders sub-panels by registration, and presets belong
    after the thing they configure, not before it.
    """

    bl_label = "Presets"
    bl_idname = "MESHAN_PT_presets"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Item"
    bl_parent_id = "MESHAN_PT_checks"
    bl_options = {"DEFAULT_CLOSED"}
    # No HIDE_HEADER: on a sub-panel it detaches the panel from its parent
    # and Blender floats it to the top of the sidebar instead.

    def draw(self, context):
        row = self.layout.row(align=True)
        row.operator("meshan.preset_save", text="Save", icon="FILE_TICK")
        row.operator("meshan.preset_load", text="Load", icon="FILEBROWSER")


class MESHAN_PT_notice(bpy.types.Panel):
    """Why the select buttons are dead on this object.

    Its own panel, registered last, purely so it lands at the very bottom of
    the Validation block -- a panel's own draw always runs above its
    sub-panels, so a note added in the parent would sit under the score bar
    instead of after everything. The message rides in the header, and `poll`
    keeps the panel out of the layout entirely on objects it does not apply
    to, so nothing is left behind when the stack is only deforming.
    """

    bl_label = "Modifier Output: Not Selectable"
    bl_idname = "MESHAN_PT_notice"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Item"
    bl_parent_id = "MESHAN_PT_item"

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return (
            obj is not None
            and obj.type == "MESH"
            and bool(results.get(uid(obj)))
            and not is_selectable(obj)
        )

    def draw_header(self, context):
        self.layout.label(text="", icon="INFO")

    def draw(self, context):
        col = self.layout.column(align=True)
        col.scale_y = 0.8
        col.label(text="Checks ran on the modifier result.")
        col.label(text="That geometry is not in the editable mesh.")


def draw_heatmap_overlay(self, context):
    """Appended to Overlays -> Geometry, right where Face Orientation sits."""
    prefs = getattr(context.scene, "meshan_settings", None)
    if prefs is None:
        return

    container = _mc_highlight_container(self.layout, context)
    container.prop(prefs, "heatmap_enable")
    if not prefs.heatmap_enable:
        return

    col = self.layout.column(align=True)
    col.row(align=True).prop(prefs, "heatmap_mode", expand=True)

    if prefs.heatmap_mode == "OBJECT":
        row = col.row(align=True)
        row.enabled = not prefs.heatmap_auto_range
        row.prop(prefs, "heatmap_range_min", text="Min")
        row.prop(prefs, "heatmap_range_max", text="Max")
    elif prefs.heatmap_mode == "TEXEL":
        col.prop(prefs, "heatmap_texel_size")

    # Last line, and both halves of it are about how the ramp is *read*
    # rather than what it measures -- Auto Range beside the Legend toggle,
    # under the range it overrides.
    row = col.row(align=True)
    row.prop(prefs, "heatmap_show_legend")
    if prefs.heatmap_mode == "OBJECT":
        row.prop(prefs, "heatmap_auto_range")


def draw_readout_overlay(self, context):
    """Appended to Overlays -> Text, below Blender's own toggles.

    Blender builds that panel as a two-column split -- General Info and
    Statistics on the left, Performance on the right -- and closes it before
    an appended function runs. There is no way in from outside to add a row
    *inside* someone else's split, so mirroring the split only lands this a
    row lower on the right, floating away from Performance with a gap beside
    it. A plain full-width row underneath is the honest layout.
    """
    prefs = getattr(context.scene, "meshan_settings", None)
    if prefs is None:
        return
    _mc_highlight_container(self.layout, context).prop(
        prefs, "show_readout", text="Validation")


# Order is registration order: Blender sorts sub-panels by it. The notice
# goes last so it sits below the whole Checks block.
classes = ((MESHAN_PT_item, MESHAN_PT_checks) + SECTION_PANELS
           + (MESHAN_PT_presets, MESHAN_PT_notice))

# Where each popover entry gets appended, most specific host first. Blender
# 5.x splits the Text toggles into their own "Text" panel; 4.2 still keeps
# them in "Guides", and blindly appending to the 5.x name makes the add-on
# fail to register on the minimum version the manifest claims to support.
_HOSTS = (
    (draw_readout_overlay,
     ("VIEW3D_PT_overlay_text", "VIEW3D_PT_overlay_guides")),
    (draw_heatmap_overlay,
     ("VIEW3D_PT_overlay_geometry",)),
)
_attached = []


def register():
    for cls in classes:
        bpy.utils.register_class(cls)

    for func, candidates in _HOSTS:
        panel = next(
            (getattr(bpy.types, name) for name in candidates
             if hasattr(bpy.types, name)), None)
        if panel is not None:
            panel.append(func)
            _attached.append((panel, func))


def unregister():
    while _attached:
        panel, func = _attached.pop()
        panel.remove(func)
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
