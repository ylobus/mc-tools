"""The validation checks and the registry that drives the UI.

Every check returns a dict with at least a ``count``:
  count > 0   issues found
  count == 0  passed
  count == -1 the check could not complete (``error`` explains why)

Optional keys:
  verts / edges / faces  offender indices, used by "select offenders"
  detail                 short text shown instead of the count
  info                   informational only, never counts as a failure
  skipped                the check did not apply (drawn as "-")
"""

import math

import bpy
import numpy as np
from mathutils import kdtree

# Quantisation before counting distinct corners: two normals or UVs closer
# than this are the same value to an exporter, and comparing raw floats would
# split a vertex over the last bit of rounding.
NORMAL_QUANT = 1e4
UV_QUANT = 1e5

DOUBLES_DISTANCE = 0.0001
ZERO_EDGE_LENGTH = 0.00001

# A face is degenerate when it has no meaningful *surface*, whatever its size.
# A fixed area threshold cannot say that: the old 1e-5 m^2 is a 3.2mm square,
# which is an ordinary face on a detailed asset and an enormous one on a mesh
# modelled in millimetres -- so it flagged perfectly good geometry and missed
# slivers on anything large.
#
# Area over perimeter squared is the same number at any scale, because both
# halves scale together. It measures shape, not size: an equilateral triangle
# is 0.0481, a square 0.0625, and anything collapsed to a line tends to zero.
# At 1e-6 a face has to be thinner than roughly 1:100,000 to count, which no
# real surface is.
DEGENERATE_SHAPE = 1e-6
ZERO_UV_AREA = 1e-9
UV_BOUNDS_EPS = 1e-4
UV_OVERLAP_EPS = 1e-7
UV_OVERLAP_MAX_TRIS = 250000
PIVOT_TOLERANCE = 0.001
ROTATION_TOLERANCE = 0.01   # degrees


# ---------------------------------------------------------------------------
# Topology
# ---------------------------------------------------------------------------

def check_ngons(bm, obj):
    faces = [f.index for f in bm.faces if len(f.verts) > 4]
    return {"count": len(faces), "faces": faces}


def check_true_nonmanifold(bm, obj):
    """Genuine topology errors: edges shared by 3+ faces, bowtie verts.

    Open boundary edges are NOT errors (see check_boundary_edges), and neither
    are loose verts -- a vertex with no edges reports is_manifold False and
    is_wire False, so it would otherwise be double-reported here on top of the
    loose-geometry check.
    """
    bad_edges = [e.index for e in bm.edges if len(e.link_faces) > 2]
    bad_verts = [
        v.index for v in bm.verts
        if v.link_edges and not v.is_manifold and not v.is_wire
    ]
    return {
        "count": len(bad_edges) + len(bad_verts),
        "edges": bad_edges,
        "verts": bad_verts,
    }


def check_boundary_edges(bm, obj):
    edges = [e.index for e in bm.edges if len(e.link_faces) == 1]
    return {"count": len(edges), "edges": edges, "info": True}


def check_lamina_faces(bm, obj):
    lamina = set()
    seen = {}
    for f in bm.faces:
        key = frozenset(v.index for v in f.verts)
        if key in seen:
            lamina.add(f.index)
            lamina.add(seen[key])
        else:
            seen[key] = f.index
    return {"count": len(lamina), "faces": list(lamina)}


# ---------------------------------------------------------------------------
# Geometry
# ---------------------------------------------------------------------------

def check_loose_geometry(bm, obj):
    loose_verts = [v.index for v in bm.verts if not v.link_edges]
    loose_edges = [e.index for e in bm.edges if not e.link_faces]
    return {
        "count": len(loose_verts) + len(loose_edges),
        "verts": loose_verts,
        "edges": loose_edges,
    }


def check_zero_length_edges(bm, obj):
    edges = [e.index for e in bm.edges if e.calc_length() < ZERO_EDGE_LENGTH]
    return {"count": len(edges), "edges": edges}


def check_zero_area_faces(bm, obj):
    """Faces collapsed to a line or a point, at any model scale."""
    faces = []
    for f in bm.faces:
        perimeter = sum(e.calc_length() for e in f.edges)
        if perimeter <= 0.0:
            faces.append(f.index)
        elif f.calc_area() / (perimeter * perimeter) < DEGENERATE_SHAPE:
            faces.append(f.index)
    return {"count": len(faces), "faces": faces}


def check_doubles(bm, obj):
    size = len(bm.verts)
    if size == 0:
        return {"count": 0, "verts": []}
    kd = kdtree.KDTree(size)
    for v in bm.verts:
        kd.insert(v.co, v.index)
    kd.balance()
    offenders = set()
    for v in bm.verts:
        for (_co, index, _dist) in kd.find_range(v.co, DOUBLES_DISTANCE):
            if index != v.index:
                offenders.add(v.index)
                offenders.add(index)
    return {"count": len(offenders), "verts": list(offenders)}


# ---------------------------------------------------------------------------
# Normals & transforms
# ---------------------------------------------------------------------------

def _edge_dir_in_face(edge, face):
    """True/False for the winding direction the edge runs in this face."""
    v0, v1 = edge.verts[0].index, edge.verts[1].index
    loop_verts = [loop.vert.index for loop in face.loops]
    n = len(loop_verts)
    for i in range(n):
        a, b = loop_verts[i], loop_verts[(i + 1) % n]
        if a == v0 and b == v1:
            return True
        if a == v1 and b == v0:
            return False
    return None


def _face_components(bm):
    """Connected components of faces (shells), as lists of BMFace."""
    seen = set()
    for start in bm.faces:
        if start.index in seen:
            continue
        seen.add(start.index)
        stack = [start]
        component = []
        while stack:
            face = stack.pop()
            component.append(face)
            for e in face.edges:
                for nf in e.link_faces:
                    if nf.index not in seen:
                        seen.add(nf.index)
                        stack.append(nf)
        yield component


def _signed_volume(faces):
    """Six times the signed volume of a closed shell.

    Negative means the winding points inward, i.e. the whole shell is
    inside-out even though its faces agree with each other.
    """
    total = 0.0
    for f in faces:
        co = [loop.vert.co for loop in f.loops]
        for i in range(1, len(co) - 1):
            total += co[0].dot(co[i].cross(co[i + 1]))
    return total


def check_flipped_normals(bm, obj):
    """Faces whose winding disagrees with their neighbours, plus whole shells
    that are consistently wound but inside-out.

    The neighbour test alone cannot see a uniformly inverted mesh (every edge
    agrees with the next), which is the most common way normals go wrong, so
    closed shells that survive it get a signed-volume test as well.
    """
    inconsistency = {f.index: 0 for f in bm.faces}
    consistency = {f.index: 0 for f in bm.faces}
    for e in bm.edges:
        if len(e.link_faces) != 2:
            continue
        f1, f2 = e.link_faces
        d1 = _edge_dir_in_face(e, f1)
        d2 = _edge_dir_in_face(e, f2)
        if d1 is None or d2 is None:
            continue
        if d1 == d2:
            inconsistency[f1.index] += 1
            inconsistency[f2.index] += 1
        else:
            consistency[f1.index] += 1
            consistency[f2.index] += 1

    offenders = {
        i for i in inconsistency
        if inconsistency[i] > 0 and inconsistency[i] >= consistency[i]
    }

    inverted_shells = 0
    for component in _face_components(bm):
        if any(f.index in offenders for f in component):
            continue  # already reported; its winding is not trustworthy anyway
        closed = all(
            len(e.link_faces) == 2 for f in component for e in f.edges
        )
        if not closed:
            continue  # open shell has no inside to be on the wrong side of
        if _signed_volume(component) < 0.0:
            inverted_shells += 1
            offenders.update(f.index for f in component)

    result = {"count": len(offenders), "faces": list(offenders)}
    if inverted_shells:
        result["detail"] = f"{inverted_shells} shell(s) inside-out"
    return result


def _loop_face_map(mesh, nl, nf):
    """Face index for each loop."""
    totals = np.empty(nf, dtype=np.int64)
    mesh.polygons.foreach_get("loop_total", totals)
    return np.repeat(np.arange(nf, dtype=np.int64), totals)


def _uv_handedness(mesh, uv, starts, totals, nf):
    """Sign of each face's UV winding, +1 or -1.

    A mirrored UV island runs the opposite way round, which flips the
    bitangent. Engines store handedness with the tangent, so a vertex shared
    between a mirrored and an unmirrored face has to split even though its
    normal and UV are identical.
    """
    nl = uv.shape[0]
    idx = np.arange(nl)
    nxt = idx + 1
    nxt[starts + totals - 1] = starts
    cross = uv[idx, 0] * uv[nxt, 1] - uv[nxt, 0] * uv[idx, 1]
    signed = np.add.reduceat(cross, starts)
    return np.where(signed < 0.0, -1, 1).astype(np.int64)


def _render_color_attribute(mesh):
    """The colour layer an exporter would write, or None."""
    attrs = getattr(mesh, "color_attributes", None)
    if not attrs:
        return None
    index = getattr(attrs, "render_color_index", -1)
    if 0 <= index < len(attrs):
        return attrs[index]
    return getattr(attrs, "active_color", None)


def engine_vertex_split(mesh):
    """(total, per-vertex split) for the engine vertex count.

    Blender counts a vertex once no matter how many different normals or UVs
    meet at it. An engine cannot: a vertex buffer entry carries exactly one
    normal, one UV per set, one tangent and one material, so every corner
    where those disagree becomes its own vertex.

    Counted here, in the order an exporter splits on:
      * normal        -- sharp edges, custom split normals
      * every UV set  -- seams, and a lightmap/second set with its own seams
      * UV handedness -- mirrored islands flip the tangent basis
      * material      -- engines cut the mesh into one section per material,
                         duplicating every vertex on the boundary
      * corner colours -- per-corner colour attributes split; per-point do not
    """
    nl = len(mesh.loops)
    nf = len(mesh.polygons)
    if nl == 0:
        # Still a pair: a mesh of loose vertices has no corners to split, and
        # callers unpack this the same way as any other result.
        return 0, np.zeros(len(mesh.vertices), dtype=np.int64)

    columns = [np.empty(nl, dtype=np.int64)]
    mesh.loops.foreach_get("vertex_index", columns[0])

    normals = np.empty(nl * 3, dtype=np.float32)
    if hasattr(mesh, "corner_normals"):
        mesh.corner_normals.foreach_get("vector", normals)
    else:                                    # pre-4.1 split-normal API
        mesh.calc_normals_split()
        mesh.loops.foreach_get("normal", normals)
    quant = np.rint(normals.reshape(-1, 3) * NORMAL_QUANT).astype(np.int64)
    columns.extend(quant[:, i] for i in range(3))

    starts = np.empty(nf, dtype=np.int64)
    totals = np.empty(nf, dtype=np.int64)
    mesh.polygons.foreach_get("loop_start", starts)
    mesh.polygons.foreach_get("loop_total", totals)

    for i, layer in enumerate(mesh.uv_layers):
        raw = np.empty(nl * 2, dtype=np.float64)
        layer.data.foreach_get("uv", raw)
        uv = raw.reshape(-1, 2)
        quant = np.rint(uv * UV_QUANT).astype(np.int64)
        columns.extend(quant[:, c] for c in range(2))
        if i == 0 and nf:
            hand = _uv_handedness(mesh, uv, starts, totals, nf)
            columns.append(hand[_loop_face_map(mesh, nl, nf)])

    if nf and len(mesh.materials) > 1:
        mat = np.empty(nf, dtype=np.int64)
        mesh.polygons.foreach_get("material_index", mat)
        columns.append(mat[_loop_face_map(mesh, nl, nf)])

    attr = _render_color_attribute(mesh)
    # Only the *render* colour layer: an exporter writes one vertex-colour
    # channel, so counting every attribute in the file would split on colours
    # that never leave Blender. Per-point colours split nothing either --
    # every corner at a vertex gets the same value.
    if attr is not None and attr.domain == 'CORNER':
        col = np.empty(nl * 4, dtype=np.float32)
        try:
            attr.data.foreach_get("color", col)
        except (AttributeError, TypeError):
            col = None
        if col is not None:
            # Quantised to 8 bits, which is how vertex colours are stored in
            # FBX and in an engine's vertex buffer.
            quant = np.rint(col.reshape(-1, 4) * 255.0).astype(np.int64)
            columns.extend(quant[:, c] for c in range(4))

    # Viewing each row as one opaque scalar lets np.unique sort it in one
    # pass, rather than lexsorting a dozen separate key columns.
    table = np.ascontiguousarray(np.stack(columns, axis=1))
    rows = table.view([("", table.dtype)] * table.shape[1])
    unique, first = np.unique(rows, return_index=True)

    # How many engine vertices each base vertex turned into. Column 0 is the
    # vertex index, so taking it at the first loop of every distinct corner
    # and counting gives the split per vertex -- which is what prices an
    # Edit-Mode selection without recounting anything.
    per_vertex = np.bincount(table[first, 0], minlength=len(mesh.vertices))
    return int(unique.size), per_vertex


def engine_vertex_count(mesh):
    """How many vertices a game engine actually receives for this mesh."""
    return engine_vertex_split(mesh)[0]


def _budget_result(actual, budget):
    """Shared shape for the budget rows: the measurement is always reported,
    and the limit joins it only once it has been passed."""
    over = actual > budget
    return {
        "count": 1 if over else 0,
        "detail": f"{actual:,} / {budget:,}" if over else f"{actual:,}",
        "verts": [],
        "note": f"{actual:,}",
    }


def check_vert_budget(obj, mesh, prefs):
    """Engine vertex count against the configured budget.

    Counted on the evaluated mesh the runner already has, so a Mirror or a
    Subdivision is priced the way the exporter will price it.
    """
    return _budget_result(engine_vertex_count(mesh), prefs.budget_verts)


def check_transforms(obj):
    s = obj.scale
    issues = []
    if any(v < 0 for v in s):
        issues.append("negative scale")
    elif abs(s.x - s.y) > 1e-6 or abs(s.y - s.z) > 1e-6:
        issues.append("non-uniform scale")
    elif any(abs(v - 1.0) > 1e-6 for v in s):
        issues.append("unapplied scale")
    return {"count": len(issues), "detail": ", ".join(issues)}


def check_pivot_centered(obj):
    dist = obj.matrix_world.translation.length
    if dist > PIVOT_TOLERANCE:
        return {"count": 1, "detail": f"{dist:.3f}m off"}
    return {"count": 0}


def _smooth_by_angle_threshold(obj):
    """Angle (radians) of a "Smooth by Angle" modifier on obj, or None.

    Blender 4.1 replaced classic Auto Smooth with a bundled geometry-nodes
    asset. Meshes using it have implicitly-hard edges (face angle above the
    threshold) with edge.smooth still True, which the explicit-sharp check
    cannot see.
    """
    for m in obj.modifiers:
        if m.type != "NODES" or not getattr(m, "node_group", None):
            continue
        if not m.node_group.name.startswith("Smooth by Angle"):
            continue
        if not m.show_viewport:
            continue
        try:
            for item in m.node_group.interface.items_tree:
                if (
                    getattr(item, "item_type", "") == "SOCKET"
                    and getattr(item, "in_out", "") == "INPUT"
                    and item.name == "Angle"
                ):
                    val = m.get(item.identifier)
                    if val is not None:
                        return float(val)
        except Exception:
            pass
        return math.radians(30.0)  # modifier present, angle unreadable
    return None


def check_hard_edges_no_seam(bm, obj):
    angle = _smooth_by_angle_threshold(obj)
    offenders = []
    for e in bm.edges:
        if len(e.link_faces) < 2:
            continue
        hard = not e.smooth
        if not hard and angle is not None and len(e.link_faces) == 2:
            try:
                hard = e.calc_face_angle() > angle
            except ValueError:
                continue  # degenerate geometry; other checks flag it
        if hard and not e.seam:
            offenders.append(e.index)
    return {"count": len(offenders), "edges": offenders}


# ---------------------------------------------------------------------------
# UVs
# ---------------------------------------------------------------------------

def _uv_layer(bm):
    return bm.loops.layers.uv.active


def _face_uv_area(face, uv_layer):
    uvs = [loop[uv_layer].uv for loop in face.loops]
    area = 0.0
    n = len(uvs)
    for i in range(n):
        a = uvs[i]
        b = uvs[(i + 1) % n]
        area += a.x * b.y - b.x * a.y
    return area * 0.5


def _range_result(actual, low, high):
    """Shared shape for the count-in-a-range rows.

    A range, not a ceiling: one UV map is as wrong as five when the pipeline
    expects two, and a mesh with no material slot arrives in engine with none.
    """
    outside = actual < low or actual > high
    limit = str(low) if low == high else f"{low}-{high}"
    return {
        "count": 1 if outside else 0,
        "detail": f"{actual} / {limit}" if outside else str(actual),
        "note": str(actual),
        # Kept apart from `note` so the viewport can pin the allowed range
        # beside the count while the panel, which already has the range in
        # the two fields next to it, shows the bare number.
        "limit": limit,
    }


def check_uv_maps(obj, mesh, prefs):
    """UV layer count against its allowed range.

    Folds in the old "UV map present" check: with a minimum of one, zero
    layers fails here, and zero layers is why every other UV check skips.

    Counted on the evaluated mesh -- UV Project and Geometry Nodes both add
    layers, and a layer that only exists after the stack still ships.
    """
    return _range_result(len(mesh.uv_layers),
                         prefs.budget_uv_maps_min, prefs.budget_uv_maps_max)


def check_materials(obj, mesh, prefs):
    """Material slot count against its allowed range.

    Slots, not distinct materials: an engine builds one draw section per
    slot, and an empty slot still makes a section.

    Read off the evaluated mesh so a material assigned by Geometry Nodes
    counts. Falls back to the object's slots when the evaluated mesh carries
    none -- slots can be linked to the object rather than the mesh data, and
    those still reach the exporter.
    """
    slots = len(mesh.materials) or len(obj.material_slots)
    return _range_result(slots,
                         prefs.budget_materials_min,
                         prefs.budget_materials_max)


def check_rotation(obj):
    """Unapplied object rotation.

    Exported as-is by some pipelines and baked by others, so the asset can
    arrive lying on its side. The companion to unapplied scale.
    """
    degrees = [math.degrees(a) for a in obj.rotation_euler]
    if all(abs(a) < ROTATION_TOLERANCE for a in degrees):
        return {"count": 0}
    worst = max(degrees, key=abs)
    return {"count": 1, "detail": f"{worst:+.1f}° unapplied"}


def check_uv_zero_area(bm, obj):
    uv = _uv_layer(bm)
    if uv is None:
        return {"count": 0, "skipped": True}
    faces = [
        f.index for f in bm.faces
        if abs(_face_uv_area(f, uv)) < ZERO_UV_AREA
    ]
    return {"count": len(faces), "faces": faces}


def check_uv_flipped(bm, obj):
    uv = _uv_layer(bm)
    if uv is None:
        return {"count": 0, "skipped": True}
    faces = [
        f.index for f in bm.faces
        if _face_uv_area(f, uv) < -ZERO_UV_AREA
    ]
    return {"count": len(faces), "faces": faces, "info": True}


def check_uv_outside(bm, obj):
    uv = _uv_layer(bm)
    if uv is None:
        return {"count": 0, "skipped": True}
    lo = -UV_BOUNDS_EPS
    hi = 1.0 + UV_BOUNDS_EPS
    faces = []
    for f in bm.faces:
        for loop in f.loops:
            u, v = loop[uv].uv
            if u < lo or u > hi or v < lo or v > hi:
                faces.append(f.index)
                break
    return {"count": len(faces), "faces": faces, "info": True}


def _spans_tiles(values):
    """True when these coordinates cover more than one UDIM tile.

    A coordinate sitting exactly ON a tile border belongs to the tile it
    closes, not the one it opens -- a shell packed flush against u=1 fills
    tile 0 and crosses nothing. Flooring the raw values would read that as
    tiles {0, 1} and flag every default-unwrapped mesh.
    """
    low = math.floor(min(values) + UV_BOUNDS_EPS)
    high = math.ceil(max(values) - UV_BOUNDS_EPS) - 1
    return high > low


def check_uv_cross_border(bm, obj):
    uv = _uv_layer(bm)
    if uv is None:
        return {"count": 0, "skipped": True}
    faces = []
    for f in bm.faces:
        us = [loop[uv].uv.x for loop in f.loops]
        vs = [loop[uv].uv.y for loop in f.loops]
        if _spans_tiles(us) or _spans_tiles(vs):
            faces.append(f.index)
    return {"count": len(faces), "faces": faces}


def _tri_area(t):
    (x0, y0), (x1, y1), (x2, y2) = t
    return 0.5 * ((x1 - x0) * (y2 - y0) - (x2 - x0) * (y1 - y0))


def _tri_overlap(t1, t2, eps=UV_OVERLAP_EPS):
    """Separating-axis test on the six edge normals of the two triangles."""
    for tri_a, tri_b in ((t1, t2), (t2, t1)):
        for i in range(3):
            ax, ay = tri_a[i]
            bx, by = tri_a[(i + 1) % 3]
            nx, ny = ay - by, bx - ax
            proj_a = [p[0] * nx + p[1] * ny for p in tri_a]
            proj_b = [p[0] * nx + p[1] * ny for p in tri_b]
            if max(proj_a) <= min(proj_b) + eps:
                return False
            if max(proj_b) <= min(proj_a) + eps:
                return False
    return True


def _tri_bounds(tris):
    """(minx, miny, maxx, maxy) per triangle, computed once.

    The grid pass, the cell sizing and the pair rejection all want these, and
    recomputing six min/max generator expressions per triangle three times
    over is a measurable slice of the overlap check on a dense mesh.
    """
    bounds = []
    for _fi, t in tris:
        (ax, ay), (bx, by), (cx, cy) = t
        bounds.append((min(ax, bx, cx), min(ay, by, cy),
                       max(ax, bx, cx), max(ay, by, cy)))
    return bounds


def _avg_tri_size(bounds):
    total = 0.0
    for minx, miny, maxx, maxy in bounds:
        total += max(maxx - minx, maxy - miny)
    return total / len(bounds)


def check_uv_overlap(bm, obj):
    """Faces whose UV triangles overlap other faces' UV triangles.

    Broad-phase is a uniform grid sized to the average triangle, so only
    nearby pairs reach the exact test. Both the triangle count and the pair
    count are capped -- on a mesh dense enough to blow the budget the honest
    answer is "could not complete", not a frozen Blender.
    """
    uv = _uv_layer(bm)
    if uv is None:
        return {"count": 0, "skipped": True}

    tris = []
    for f in bm.faces:
        uvs = [tuple(loop[uv].uv) for loop in f.loops]
        for i in range(1, len(uvs) - 1):
            t = (uvs[0], uvs[i], uvs[i + 1])
            if abs(_tri_area(t)) > ZERO_UV_AREA:
                tris.append((f.index, t))

    if len(tris) > UV_OVERLAP_MAX_TRIS:
        return {"count": -1, "error": "mesh too dense for UV overlap check"}
    if not tris:
        return {"count": 0, "faces": []}

    bounds = _tri_bounds(tris)
    cell = max(_avg_tri_size(bounds), 1e-5)
    grid = {}
    for idx, (minx, miny, maxx, maxy) in enumerate(bounds):
        for gx in range(int(minx / cell), int(maxx / cell) + 1):
            for gy in range(int(miny / cell), int(maxy / cell) + 1):
                grid.setdefault((gx, gy), []).append(idx)

    offenders = set()
    tested = set()
    budget = 2_000_000
    for bucket in grid.values():
        n = len(bucket)
        for i in range(n):
            for j in range(i + 1, n):
                a, b = bucket[i], bucket[j]
                fa, ta = tris[a]
                fb, tb = tris[b]
                if fa == fb:
                    continue

                # Bounding boxes first. This is not a heuristic: the x and y
                # axes are two of the six separating axes the exact test
                # tries, so anything rejected here would be rejected there
                # too -- for four comparisons instead of a full SAT pass.
                # Neighbouring triangles share grid cells constantly, so
                # this is where most of the pair budget used to go.
                aminx, aminy, amaxx, amaxy = bounds[a]
                bminx, bminy, bmaxx, bmaxy = bounds[b]
                if (amaxx <= bminx + UV_OVERLAP_EPS
                        or bmaxx <= aminx + UV_OVERLAP_EPS
                        or amaxy <= bminy + UV_OVERLAP_EPS
                        or bmaxy <= aminy + UV_OVERLAP_EPS):
                    continue

                key = (a, b)
                if key in tested:
                    continue
                tested.add(key)
                budget -= 1
                if budget <= 0:
                    return {
                        "count": -1,
                        "error": "UV overlap check aborted (too many pairs)",
                    }
                if _tri_overlap(ta, tb):
                    offenders.add(fa)
                    offenders.add(fb)

    return {"count": len(offenders), "faces": list(offenders)}


# ---------------------------------------------------------------------------
# Registry -- drives the runner, the panel sections and the settings
# ---------------------------------------------------------------------------

# Labels are kept short: they sit in a narrow sidebar column and again in the
# viewport readout, where a long name pushes the value column across the view.
# The check ids never change, so a rename costs nothing downstream.
# Ordered cheapest-to-act-on first: budgets and transforms are decisions you
# make about the whole asset, geometry and topology are cleanup, UVs last
# because they depend on everything above being settled.
#
# Names are short because they sit in a narrow sidebar column and again in the
# viewport readout, and because the category already supplies the context --
# "Flipped" under UVs cannot be confused with "Flipped" under Normals.
SECTIONS = [
    ("budget", "Budget", "MOD_DECIM", [
        ("vert_budget", "GPU Verts", check_vert_budget),
        ("uv_maps", "UV Maps", check_uv_maps),
        ("materials", "Materials", check_materials),
    ]),
    ("transforms", "Transforms", "OBJECT_ORIGIN", [
        ("pivot", "World-center Pivot", check_pivot_centered),
        ("rotation", "Applied Rotation", check_rotation),
        ("transforms", "Applied Scale", check_transforms),
    ]),
    ("geometry", "Geometry", "SNAP_VERTEX", [
        ("loose", "Loose Geometry", check_loose_geometry),
        ("doubles", "Duplicate Vertices", check_doubles),
        ("zero_edges", "Zero-length Edges", check_zero_length_edges),
        ("zero_faces", "Zero-area Faces", check_zero_area_faces),
    ]),
    ("topology", "Topology", "OUTLINER_DATA_MESH", [
        ("ngons", "N-gons", check_ngons),
        ("nonmanifold", "Non-manifold", check_true_nonmanifold),
        ("lamina", "Lamina Faces", check_lamina_faces),
        ("boundary", "Boundary Edges", check_boundary_edges),
    ]),
    ("normals", "Normals", "ORIENTATION_NORMAL", [
        ("flipped", "Flipped", check_flipped_normals),
        ("hard_edges", "Sharps w/o Seam", check_hard_edges_no_seam),
    ]),
    ("uvs", "UVs", "UV", [
        ("uv_outside", "UDIM Overflow", check_uv_outside),
        ("uv_overlap", "Overlap", check_uv_overlap),
        ("uv_flipped", "Flipped", check_uv_flipped),
        ("uv_zero", "Zero-area", check_uv_zero_area),
        ("uv_cross", "Cross-border", check_uv_cross_border),
    ]),
]

# What each check looks for, why it matters, and what usually causes it.
# Shown on hover in the sidebar -- a name alone does not tell you whether a
# result is a real problem or an expected property of the asset.
DESCRIPTIONS = {
    "ngons": (
        "Faces with more than 4 sides.\n"
        "They triangulate unpredictably, so the engine may split them "
        "differently from your viewport and shade them differently too.\n"
        "The wrench dissolves the stray mid-edge verts that cause most of "
        "them; genuine 5+ corner shapes are left for you to retopologise"
    ),
    "nonmanifold": (
        "Topology that cannot exist on a real surface: edges shared by three "
        "or more faces, and bowtie vertices where two cones meet at a point.\n"
        "Breaks booleans, subdivision, baking and physics.\n"
        "Open boundary edges are NOT counted here -- those are the separate "
        "Boundary edges check"
    ),
    "boundary": (
        "Edges with only one face -- the open border of a surface.\n"
        "Informational, never a failure: correct on hair cards, planes and "
        "any cut-open shell, and a hole on something meant to be watertight.\n"
        "Worth a look on a closed asset, ignore on flat geometry"
    ),
    "lamina": (
        "Two faces built on exactly the same vertices, stacked invisibly.\n"
        "They z-fight when rendered and double the surface an engine has to "
        "shade.\n"
        "Usually left behind by a duplicate-and-merge, or by extruding zero "
        "distance. The wrench deletes the copies and keeps one"
    ),
    "loose": (
        "Vertices with no edges, and edges with no faces.\n"
        "They carry no surface, so they render as nothing, but they still "
        "cost vertices in the export and can confuse exporters into emitting "
        "stray points.\n"
        "Usually the residue of a delete-faces that left its verts behind"
    ),
    "zero_edges": (
        "Edges shorter than 0.01mm -- two vertices sitting on top of each "
        "other but not merged.\n"
        "Any face using one has a degenerate corner, so normals and tangents "
        "there are meaningless.\n"
        "The wrench collapses them"
    ),
    "zero_faces": (
        "Faces collapsed to a line or a point: no surface, so no normal and "
        "no tangent can be computed for them.\n"
        "They bake as black or garbage in a normal map, and can spread bad "
        "normals to the faces around them -- which is why a mesh can look "
        "perfectly fine in the viewport and still fail here.\n"
        "Measured by SHAPE, not size: area divided by perimeter squared, so "
        "the test means the same thing on a 1mm bolt and a 100m terrain. A "
        "small face is fine; a thin sliver is not.\n"
        "Usually left by a boolean, a bad merge, or a bevel meeting itself"
    ),
    "doubles": (
        "Vertices within 0.1mm of another one.\n"
        "They split the surface invisibly: shading breaks across the seam, "
        "and the engine counts both.\n"
        "The wrench merges by distance. Careful on geometry that is meant to "
        "be split, such as separate hair cards sharing a silhouette"
    ),
    "uv_zero": (
        "Faces with real surface but no UV area -- their UV corners are "
        "collapsed together.\n"
        "They take one texel of whatever happens to be under that point, so "
        "they bake to a flat smear. A silent bake killer, because the 3D "
        "geometry looks correct"
    ),
    "uv_overlap": (
        "Faces whose UV islands sit on top of each other.\n"
        "Baking writes both into the same texels, so one overwrites the "
        "other and the result is dirty.\n"
        "Turn this off when you stack or mirror shells deliberately to save "
        "texture space -- then it is intentional, not a fault"
    ),
    "uv_cross": (
        "A single face spanning more than one UDIM tile.\n"
        "A face has to live in one tile; most engines and bakers either clamp "
        "it or drop it.\n"
        "Usually a shell that was moved without snapping"
    ),
    "uv_outside": (
        "UVs outside the 0-1 square.\n"
        "Informational: correct when you are tiling a texture on purpose, or "
        "working in UDIMs. A problem only if the asset is meant to fit one "
        "0-1 space"
    ),
    "uv_flipped": (
        "Faces whose UV winding is mirrored relative to the rest.\n"
        "Informational: standard practice for mirrored geometry sharing one "
        "texture. Worth knowing about because a mirrored island flips the "
        "tangent basis, which splits vertices on export and can flip the "
        "green channel of a normal map"
    ),
    "flipped": (
        "Faces pointing the wrong way -- both those that disagree with their "
        "neighbours and whole closed shells that are consistently wound but "
        "inside-out.\n"
        "Backface culling makes them vanish in engine, and lighting reads "
        "inverted.\n"
        "The whole-shell case is the common one and the neighbour test alone "
        "cannot see it, so closed shells also get a volume test.\n"
        "The wrench recalculates outside"
    ),
    "hard_edges": (
        "Edges marked sharp that carry no UV seam.\n"
        "A sharp edge splits the normal; if the UVs are not split there too, "
        "the tangent basis is continuous across a discontinuous normal and "
        "the normal map shows a visible seam.\n"
        "Understands both workflows: explicit Sharp marks, and the 4.1+ "
        "Smooth by Angle modifier"
    ),
    "transforms": (
        "Negative, non-uniform or unapplied object scale.\n"
        "Unapplied scale is exported as-is by some pipelines and baked by "
        "others, so the asset arrives at the wrong size. Negative scale "
        "inverts normals. Non-uniform scale skews normal maps.\n"
        "The wrench applies scale to this object only"
    ),
    "rotation": (
        "Unapplied object rotation.\n"
        "Exported as-is by some pipelines and baked by others, so the asset "
        "can arrive lying on its side, and its local axes will not match "
        "what the engine expects for movement or attachment.\n"
        "The companion to unapplied scale: apply both before handing an "
        "asset over"
    ),
    "pivot": (
        "Whether the object origin sits within 1mm of world zero.\n"
        "Some pipelines expect assets authored at the origin; others want the "
        "pivot at a mount point.\n"
        "Never auto-fixed: moving a pivot moves the mesh relative to it, so "
        "the right answer depends on the asset"
    ),
    "vert_budget": (
        "Vertex count as the ENGINE will see it, against your budget.\n"
        "Blender counts a vertex once however many normals or UVs meet "
        "there; an engine cannot, because one vertex carries one normal and "
        "one UV per set. Every corner where those disagree becomes its own "
        "vertex.\n"
        "Splits on: normals (sharp edges), each UV set, mirrored-island "
        "handedness, material boundaries, and per-corner colours.\n"
        "A default cube is 8 verts in Blender and 24 in engine.\n"
        "Measured after modifiers, and reported even when it passes"
    ),
    "uv_maps": (
        "How many UV layers the mesh has, against your budget.\n"
        "None at all is a failure: nothing can be textured or baked, and "
        "every other UV check has nothing to run on.\n"
        "Each extra set is a second full set of UVs in the vertex buffer, "
        "and its seams split vertices again -- so a lightmap set is never "
        "free"
    ),
    "materials": (
        "How many material slots the mesh uses, against your budget.\n"
        "Engines cut a mesh into one draw section per material, so this is "
        "the single biggest lever on the draw calls the asset costs: two "
        "materials on one mesh is two draw calls, not one.\n"
        "Vertices on the boundary between sections are duplicated as well, "
        "so materials also push the engine vertex count up.\n"
        "Empty slots are not counted"
    ),
}


# Checks that read the object's transform rather than its geometry. No
# modifier can move an object's own scale or origin, so these take the
# object alone: `fn(obj)`.
OBJECT_LEVEL_IDS = {"transforms", "rotation", "pivot"}

# Checks that read mesh *data* rather than topology, against a configurable
# limit: `fn(obj, mesh, prefs)`, where `mesh` is the evaluated mesh.
MESH_LEVEL_IDS = {"vert_budget", "uv_maps", "materials"}

# Checks with nothing selectable to jump to.
NON_SELECTABLE_IDS = {
    "transforms", "rotation", "pivot", "vert_budget", "uv_maps",
    "materials",
}
