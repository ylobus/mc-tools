"""Validation -- what is wrong with this mesh.

The checks themselves (`checks`), the runner and result store (`results`),
the operators that drive them, the sidebar panels, and the shareable check
configuration (`presets`).

The split from `visualization` is by question, not by technology: this half
answers "does this asset pass", the other half answers "where is the cost".
They share the settings on `Scene.meshan_settings` and nothing else --
`visualization` imports from here (it draws these results), never the
reverse.
"""

from . import checks, operators, presets, results, ui  # noqa: F401
