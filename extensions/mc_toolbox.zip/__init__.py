import bpy


def mc_highlight_on(context):
    """True when the MC Highlight session toggle is enabled.

    Uses getattr with a default so any MC tool can call it safely even when
    MC Toolbox is not installed (the property simply won't exist).
    """
    return getattr(context.window_manager, "mc_highlight", False)


def mc_highlight_container(layout, context):
    """Return the sub-layout MC buttons should be drawn into.

    When MC Highlight is on, it's a bordered ``box()`` carrying Blender's
    'alert' (error/red) styling — border + error colour together. When off,
    it's a plain aligned row, so the normal UI is untouched. The returned
    layout is always horizontal, so buttons drawn into it stay side by side.

    Shared, dependency-free convention: every MC tool copies this small helper
    and draws its buttons into the returned layout (no cross-extension imports).
    """
    if mc_highlight_on(context):
        box = layout.box()
        box.alert = True
        row = box.row(align=True)
        row.alert = True
        return row
    return layout.row(align=True)


class MC_MT_tools(bpy.types.Menu):
    """MightyCanvas tools and shared actions."""
    bl_idname = "MC_MT_tools"
    bl_label = "MC-Tools"

    def draw(self, context):
        # The menu's own entry in the header bar carries the highlight; the
        # items inside the dropdown draw plainly.
        self.layout.prop(context.window_manager, "mc_highlight", text="MC Highlight")

        # Future operations get added below.


def draw_mc_menu(self, context):
    # Own container so the highlight styling stays on the MC-Tools entry only,
    # not the sibling View / Select / Add menus.
    container = mc_highlight_container(self.layout, context)
    container.menu(MC_MT_tools.bl_idname, text="MC-Tools")


classes = (
    MC_MT_tools,
)


def register():
    bpy.types.WindowManager.mc_highlight = bpy.props.BoolProperty(
        name="MC Highlight",
        description="Highlight buttons contributed by MightyCanvas tools",
        default=False,
    )

    for cls in classes:
        bpy.utils.register_class(cls)

    # Append so MC-Tools sits at the end of the header menu bar.
    bpy.types.VIEW3D_MT_editor_menus.append(draw_mc_menu)


def unregister():
    bpy.types.VIEW3D_MT_editor_menus.remove(draw_mc_menu)

    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)

    del bpy.types.WindowManager.mc_highlight
