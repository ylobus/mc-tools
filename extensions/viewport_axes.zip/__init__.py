import bpy, gpu, mathutils
from gpu_extras.batch import batch_for_shader

_handle = None

DIM = 0.25   # brightness of the dim (negative-direction) end of each gradient line


def draw_callback():
    ctx    = bpy.context
    region = ctx.region
    rv3d   = ctx.region_data
    if rv3d is None:
        return

    # Follow the viewport's master "Show Overlays" toggle.
    space = ctx.space_data
    if space is None or not space.overlay.show_overlays:
        return

    if not ctx.scene.show_viewport_axes:
        return

    # The WINDOW region excludes the header, so its full height already stops
    # right beneath the mode/tool header — no manual top clamp needed.
    W, H = region.width, region.height
    vm   = rv3d.view_matrix.to_3x3()

    AXES = [
        (mathutils.Vector((1, 0, 0)), (0.90, 0.22, 0.22, 1.0)),
        (mathutils.Vector((0, 1, 0)), (0.45, 0.78, 0.16, 1.0)),
        (mathutils.Vector((0, 0, 1)), (0.20, 0.50, 1.00, 1.0)),
    ]

    proj = []
    for v, col in AXES:
        d = vm @ v
        proj.append((d.x, d.y, col, d.x * d.x + d.y * d.y))
    proj.sort(key=lambda p: p[3])
    a, b = proj[1], proj[2]

    if abs(a[0]) * abs(b[1]) >= abs(a[1]) * abs(b[0]):
        horiz, vert = a, b
    else:
        horiz, vert = b, a

    shader = gpu.shader.from_builtin('SMOOTH_COLOR')
    gpu.state.blend_set('ALPHA')
    gpu.state.line_width_set(1.0)

    def grad_line(p_pos, p_neg, col):
        full = col
        dim  = (col[0] * DIM, col[1] * DIM, col[2] * DIM, col[3])
        batch = batch_for_shader(
            shader, 'LINES',
            {"pos": [p_neg, p_pos], "color": [dim, full]})
        batch.draw(shader)

    # Horizontal axis along the bottom border (full width)
    dx, dy, col, _ = horiz
    if dx >= 0:
        grad_line((W, 0), (0, 0), col)
    else:
        grad_line((0, 0), (W, 0), col)

    # Vertical axis along the left border (full height)
    dx, dy, col, _ = vert
    if dy >= 0:
        grad_line((0, H), (0, 0), col)
    else:
        grad_line((0, 0), (0, H), col)

    gpu.state.line_width_set(1.0)
    gpu.state.blend_set('NONE')


def _mc_highlight_container(layout, context):
    """MC Highlight (see MC Tools): when on, draw into a red-alert bordered box;
    otherwise a plain horizontal row. Loose-coupled convention, no imports."""
    if getattr(context.window_manager, "mc_highlight", False):
        box = layout.box()
        box.alert = True
        row = box.row(align=True)
        row.alert = True
        return row
    return layout.row(align=True)


def draw_viewport_axes_toggle(self, context):
    container = _mc_highlight_container(self.layout, context)
    container.prop(context.scene, "show_viewport_axes")


def register():
    global _handle

    bpy.types.Scene.show_viewport_axes = bpy.props.BoolProperty(
        name="Viewport Axes",
        description="Show world axis directions as gradient lines on the viewport borders",
        default=True,
    )

    # Prepend so the toggle sits at the top of the Overlays → Guides panel.
    bpy.types.VIEW3D_PT_overlay_guides.prepend(draw_viewport_axes_toggle)

    _handle = bpy.types.SpaceView3D.draw_handler_add(
        draw_callback, (), 'WINDOW', 'POST_PIXEL')


def unregister():
    global _handle

    bpy.types.VIEW3D_PT_overlay_guides.remove(draw_viewport_axes_toggle)

    if _handle:
        bpy.types.SpaceView3D.draw_handler_remove(_handle, 'WINDOW')
        _handle = None

    del bpy.types.Scene.show_viewport_axes
