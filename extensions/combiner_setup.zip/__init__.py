import bpy

COLOR_ITEMS = [
    ('NONE', "None", "", 'OUTLINER_COLLECTION', 0),
    ('COLOR_01', "Red", "", 'COLLECTION_COLOR_01', 1),
    ('COLOR_02', "Orange", "", 'COLLECTION_COLOR_02', 2),
    ('COLOR_03', "Yellow", "", 'COLLECTION_COLOR_03', 3),
    ('COLOR_04', "Green", "", 'COLLECTION_COLOR_04', 4),
    ('COLOR_05', "Blue", "", 'COLLECTION_COLOR_05', 5),
    ('COLOR_06', "Violet", "", 'COLLECTION_COLOR_06', 6),
    ('COLOR_07', "Pink", "", 'COLLECTION_COLOR_07', 7),
    ('COLOR_08', "Brown", "", 'COLLECTION_COLOR_08', 8),
]


class CombinerSetupPreferences(bpy.types.AddonPreferences):
    bl_idname = __package__

    # =====================================================================
    # Target Collections
    # =====================================================================
    procedural_collection: bpy.props.StringProperty(
        name="Procedural", default="Procedural",
        description="Parent collection for procedural setups",
    )
    gameres_collection: bpy.props.StringProperty(
        name="GameRes", default="GameRes",
        description="Collection for game-res meshes",
    )
    substance_collection: bpy.props.StringProperty(
        name="Substance", default="Substance",
        description="Collection for substance meshes",
    )

    # =====================================================================
    # Root Collection
    # =====================================================================
    root_color: bpy.props.EnumProperty(
        name="Collection Color", items=COLOR_ITEMS, default='COLOR_04',
    )

    # =====================================================================
    # Sub-Collections
    # =====================================================================
    lowpoly_prefix: bpy.props.StringProperty(name="Prefix", default="L_")
    lowpoly_suffix: bpy.props.StringProperty(name="Suffix", default="")
    lowpoly_color: bpy.props.EnumProperty(
        name="Collection Color", items=COLOR_ITEMS, default='COLOR_05',
    )

    highres_prefix: bpy.props.StringProperty(name="Prefix", default="H_")
    highres_suffix: bpy.props.StringProperty(name="Suffix", default="")
    highres_color: bpy.props.EnumProperty(
        name="Collection Color", items=COLOR_ITEMS, default='COLOR_04',
    )

    # =====================================================================
    # Object Naming
    # =====================================================================
    pivot_prefix: bpy.props.StringProperty(name="Prefix", default="U_")
    pivot_suffix: bpy.props.StringProperty(name="Suffix", default="")

    child_prefix: bpy.props.StringProperty(name="Prefix", default="")
    child_suffix: bpy.props.StringProperty(name="Suffix", default="_el.001")
    child_vertex_group: bpy.props.StringProperty(
        name="Default Vertex Group", default="Exclude",
        description="Empty vertex group created on the child mesh",
    )

    gameres_prefix: bpy.props.StringProperty(name="Prefix", default="n_")
    gameres_suffix: bpy.props.StringProperty(name="Suffix", default=":mesh_lod0")

    substance_prefix: bpy.props.StringProperty(name="Prefix", default="")
    substance_suffix: bpy.props.StringProperty(name="Suffix", default="_substance")

    def draw(self, context):
        layout = self.layout

        # --- Target Collections ---
        header = layout.box()
        header.label(text="Target Collections", icon='OUTLINER_COLLECTION')
        col = header.column(align=True)
        col.prop(self, "procedural_collection")
        col.prop(self, "gameres_collection")
        col.prop(self, "substance_collection")

        layout.separator()

        # --- Collection Hierarchy ---
        header = layout.box()
        header.label(text="Collection Hierarchy", icon='OUTLINER')

        # Root
        sub = header.box()
        sub.label(text="Root", icon='FILE_FOLDER')
        sub.prop(self, "root_color")

        # Highres
        sub = header.box()
        sub.label(text="Highres Sub-Collection", icon='FILE_FOLDER')
        row = sub.row(align=True)
        row.prop(self, "highres_prefix")
        row.prop(self, "highres_suffix")
        sub.prop(self, "highres_color")

        # Lowpoly
        sub = header.box()
        sub.label(text="Lowpoly Sub-Collection", icon='FILE_FOLDER')
        row = sub.row(align=True)
        row.prop(self, "lowpoly_prefix")
        row.prop(self, "lowpoly_suffix")
        sub.prop(self, "lowpoly_color")

        layout.separator()

        # --- Object Naming ---
        header = layout.box()
        header.label(text="Object Naming", icon='OBJECT_DATA')

        # Pivot
        sub = header.box()
        sub.label(text="Pivot (Empty)", icon='EMPTY_AXIS')
        row = sub.row(align=True)
        row.prop(self, "pivot_prefix")
        row.prop(self, "pivot_suffix")

        # Child Mesh
        sub = header.box()
        sub.label(text="Child Mesh", icon='MESH_DATA')
        row = sub.row(align=True)
        row.prop(self, "child_prefix")
        row.prop(self, "child_suffix")
        sub.prop(self, "child_vertex_group")

        # GameRes
        sub = header.box()
        sub.label(text="GameRes Mesh", icon='MESH_DATA')
        row = sub.row(align=True)
        row.prop(self, "gameres_prefix")
        row.prop(self, "gameres_suffix")

        # Substance
        sub = header.box()
        sub.label(text="Substance Mesh", icon='MESH_DATA')
        row = sub.row(align=True)
        row.prop(self, "substance_prefix")
        row.prop(self, "substance_suffix")


class OUTLINER_OT_create_procedural(bpy.types.Operator):
    """Creates a Procedural collection with optional GameRes and Substance meshes."""

    bl_idname = "outliner.create_procedural"
    bl_label = "Combiner Setup"
    bl_options = {'REGISTER', 'UNDO'}

    name: bpy.props.StringProperty(name="Name")
    parent_collection: bpy.props.StringProperty(name="Parent Collection")
    add_affixes: bpy.props.BoolProperty(
        name="Add Prefixes/Suffixes",
        default=False,
        description="Apply configured prefixes/suffixes to pivot, GameRes and Substance names",
    )
    create_gameres: bpy.props.BoolProperty(
        name="GameRes", default=True,
        description="Create a mesh in GameRes with the Combiner modifier",
    )
    create_substance: bpy.props.BoolProperty(
        name="Substance", default=False,
        description="Create a mesh in Substance with the Combiner modifier",
    )
    create_highres: bpy.props.BoolProperty(
        name="Highres", default=False,
        description="Create a highres sub-collection",
    )

    def invoke(self, context, event):
        prefs = context.preferences.addons[__package__].preferences
        self.name = ""
        self.parent_collection = prefs.procedural_collection
        self.add_affixes = False
        self.create_gameres = True
        self.create_substance = False
        self.create_highres = False
        return context.window_manager.invoke_props_dialog(self)

    def draw(self, context):
        layout = self.layout

        layout.prop(self, "name")
        layout.prop_search(self, "parent_collection", bpy.data, "collections", text="Parent")

        layout.separator()

        box = layout.box()
        box.label(text="Options", icon='PREFERENCES')
        box.prop(self, "add_affixes")
        box.prop(self, "create_highres")

        box = layout.box()
        box.label(text="Linked Meshes", icon='MESH_DATA')
        row = box.row(align=True)
        row.prop(self, "create_gameres", toggle=True)
        row.prop(self, "create_substance", toggle=True)

    def _affix(self, base, prefix, suffix):
        """Build name: prefix + base + suffix."""
        return f"{prefix}{base}{suffix}"

    def _create_combiner_mesh(self, collection, obj_name, combiner_ng, linked_col, root_obj,
                               override_material=False):
        """Create an empty mesh with a Combiner modifier in the given collection."""
        mesh_data = bpy.data.meshes.new(obj_name)
        obj = bpy.data.objects.new(obj_name, mesh_data)
        collection.objects.link(obj)

        mod = obj.modifiers.new(name="Combiner", type='NODES')
        mod.node_group = combiner_ng

        for item in combiner_ng.interface.items_tree:
            if not hasattr(item, 'identifier'):
                continue
            if item.name == "Input Type":
                mod[item.identifier] = 0
            elif item.name == "Collection":
                mod[item.identifier] = linked_col
            elif item.name == "Root":
                mod[item.identifier] = root_obj
            elif item.name == "Override Material" and override_material:
                mod[item.identifier] = True

        return obj

    def execute(self, context):
        prefs = context.preferences.addons[__package__].preferences
        name = self.name.strip()

        if not name:
            self.report({'ERROR'}, "Name cannot be empty")
            return {'CANCELLED'}

        # --- Check for duplicate collection name ---
        if name in bpy.data.collections:
            self.report({'ERROR'}, f"A collection named '{name}' already exists")
            return {'CANCELLED'}

        # --- Find parent collection ---
        parent_col = bpy.data.collections.get(self.parent_collection)
        if not parent_col:
            self.report({'ERROR'}, f"'{self.parent_collection}' collection not found")
            return {'CANCELLED'}

        # --- Validate optional targets ---
        combiner_ng = None
        gameres_col = None
        substance_col = None

        if self.create_gameres or self.create_substance:
            combiner_ng = bpy.data.node_groups.get("Combiner")
            if not combiner_ng:
                self.report({'ERROR'}, "'Combiner' node group not found. Make sure it's loaded from your assets.")
                return {'CANCELLED'}

        if self.create_gameres:
            gameres_col = bpy.data.collections.get(prefs.gameres_collection)
            if not gameres_col:
                self.report({'ERROR'}, f"'{prefs.gameres_collection}' collection not found")
                return {'CANCELLED'}

        if self.create_substance:
            substance_col = bpy.data.collections.get(prefs.substance_collection)
            if not substance_col:
                self.report({'ERROR'}, f"'{prefs.substance_collection}' collection not found")
                return {'CANCELLED'}

        # --- Root collection under parent ---
        root_col = bpy.data.collections.new(name)
        root_col.color_tag = prefs.root_color
        parent_col.children.link(root_col)

        # --- Pivot in root collection ---
        if self.add_affixes:
            pivot_name = self._affix(name, prefs.pivot_prefix, prefs.pivot_suffix)
        else:
            pivot_name = name
        empty_obj = bpy.data.objects.new(pivot_name, None)
        empty_obj.empty_display_type = 'PLAIN_AXES'
        empty_obj.empty_display_size = 0.1
        empty_obj.show_name = True
        empty_obj.show_in_front = True
        root_col.objects.link(empty_obj)

        # --- Highres sub-collection (created first so it sits above lowres) ---
        if self.create_highres:
            highres_col_name = self._affix(name, prefs.highres_prefix, prefs.highres_suffix)
            highres_col = bpy.data.collections.new(highres_col_name)
            highres_col.color_tag = prefs.highres_color
            root_col.children.link(highres_col)

        # --- Lowpoly sub-collection ---
        lowpoly_col_name = self._affix(name, prefs.lowpoly_prefix, prefs.lowpoly_suffix)
        lowpoly_col = bpy.data.collections.new(lowpoly_col_name)
        lowpoly_col.color_tag = prefs.lowpoly_color
        root_col.children.link(lowpoly_col)

        # --- Child mesh in lowpoly, parented to pivot ---
        child_name = self._affix(name, prefs.child_prefix, prefs.child_suffix)
        child_mesh_data = bpy.data.meshes.new(child_name)
        child_mesh_obj = bpy.data.objects.new(child_name, child_mesh_data)
        lowpoly_col.objects.link(child_mesh_obj)
        child_mesh_obj.parent = empty_obj

        # Create default vertex group
        vg_name = prefs.child_vertex_group.strip()
        if vg_name:
            child_mesh_obj.vertex_groups.new(name=vg_name)

        # --- GameRes mesh ---
        if self.create_gameres:
            if self.add_affixes:
                gr_name = self._affix(name, prefs.gameres_prefix, prefs.gameres_suffix)
            else:
                gr_name = name
            self._create_combiner_mesh(gameres_col, gr_name, combiner_ng, lowpoly_col, empty_obj)

        # --- Substance mesh (with Override Material enabled) ---
        if self.create_substance:
            if self.add_affixes:
                sub_name = self._affix(name, prefs.substance_prefix, prefs.substance_suffix)
            else:
                sub_name = self._affix(name, "", prefs.substance_suffix)
            self._create_combiner_mesh(
                substance_col, sub_name, combiner_ng, lowpoly_col, empty_obj,
                override_material=True,
            )

        self.report({'INFO'}, f"Created combiner setup: {name}")
        return {'FINISHED'}


def _mc_highlight_container(layout, context):
    """MC Highlight (see MC Tools): when on, draw into a red-alert bordered box;
    otherwise a plain horizontal row. Loose-coupled convention, no imports."""
    if getattr(context.window_manager, "mc_highlight", False):
        box = layout.box()
        box.alert = True
        row = box.row(align=True)
        row.alert = True
        return row
    return layout.row(align=True)


def draw_outliner_button(self, context):
    if context.space_data.type != 'OUTLINER':
        return

    container = _mc_highlight_container(self.layout, context)
    container.operator(
        OUTLINER_OT_create_procedural.bl_idname,
        text="",
        icon='PLUS',
    )


def register():
    bpy.utils.register_class(CombinerSetupPreferences)
    bpy.utils.register_class(OUTLINER_OT_create_procedural)
    bpy.types.OUTLINER_HT_header.append(draw_outliner_button)


def unregister():
    bpy.types.OUTLINER_HT_header.remove(draw_outliner_button)
    bpy.utils.unregister_class(OUTLINER_OT_create_procedural)
    bpy.utils.unregister_class(CombinerSetupPreferences)
