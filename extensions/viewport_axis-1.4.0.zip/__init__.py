import bpy, gpu, mathutils
from gpu_extras.batch import batch_for_shader

_handle = None

TOP_OFFSET = 70
DIM        = 0.25


def draw_callback():
    ctx    = bpy.context
    region = ctx.region
    rv3d   = ctx.region_data
    if rv3d is None:
        return

    if not ctx.scene.show_axis_edge_indicator:
        return

    W, H = region.width, region.height
    TOP  = H - TOP_OFFSET
    vm   = rv3d.view_matrix.to_3x3()

    AXES = [
        (mathutils.Vector((1, 0, 0)), (0.90, 0.22, 0.22, 1.0)),
        (mathutils.Vector((0, 1, 0)), (0.45, 0.78, 0.16, 1.0)),
        (mathutils.Vector((0, 0, 1)), (0.20, 0.50, 1.00, 1.0)),
    ]

    proj = []
    for v, col in AXES:
        d = vm @ v
        proj.append((d.x, d.y, col, d.x * d.x + d.y * d.y))
    proj.sort(key=lambda p: p[3])
    a, b = proj[1], proj[2]

    if abs(a[0]) * abs(b[1]) >= abs(a[1]) * abs(b[0]):
        horiz, vert = a, b
    else:
        horiz, vert = b, a

    shader = gpu.shader.from_builtin('SMOOTH_COLOR')
    gpu.state.blend_set('ALPHA')
    gpu.state.line_width_set(1.0)

    def grad_line(p_pos, p_neg, col):
        full = col
        dim  = (col[0] * DIM, col[1] * DIM, col[2] * DIM, col[3])
        batch = batch_for_shader(
            shader, 'LINES',
            {"pos": [p_neg, p_pos], "color": [dim, full]})
        batch.draw(shader)

    dx, dy, col, _ = horiz
    if dx >= 0:
        grad_line((W, 0), (0, 0), col)
    else:
        grad_line((0, 0), (W, 0), col)

    dx, dy, col, _ = vert
    if dy >= 0:
        grad_line((0, TOP), (0, 0), col)
    else:
        grad_line((0, 0), (0, TOP), col)

    gpu.state.line_width_set(1.0)
    gpu.state.blend_set('NONE')


def draw_axis_edge_toggle(self, context):
    self.layout.prop(context.scene, "show_axis_edge_indicator")


def register():
    global _handle

    bpy.types.Scene.show_axis_edge_indicator = bpy.props.BoolProperty(
        name="Edge Axis Indicator",
        description="Show axis direction as gradient lines on viewport borders",
        default=True,
    )

    bpy.types.VIEW3D_PT_overlay_guides.append(draw_axis_edge_toggle)

    _handle = bpy.types.SpaceView3D.draw_handler_add(
        draw_callback, (), 'WINDOW', 'POST_PIXEL')


def unregister():
    global _handle

    bpy.types.VIEW3D_PT_overlay_guides.remove(draw_axis_edge_toggle)

    if _handle:
        bpy.types.SpaceView3D.draw_handler_remove(_handle, 'WINDOW')
        _handle = None

    del bpy.types.Scene.show_axis_edge_indicator
